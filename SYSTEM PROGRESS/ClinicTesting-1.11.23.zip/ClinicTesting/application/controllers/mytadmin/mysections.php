<?php
class Mysections extends CI_Controller{
	public function __construct(){
	parent:: __construct();
	if (!$this->session->userdata('loggedin')){
			redirect('login');
		}
	}
	public function index(){	
		$data['sections']=$this->Section_model->get_sections('id','DESC',200);	
		//view
		
		$data['main_content']= 'myadmin/sections/index';
		
		$this->load->view('myadmin/layouts/main',$data);
	}

public function add(){
		$this->form_validation->set_rules('code','Code','trim|required|min_length[1]');
		$this->form_validation->set_rules('name','Name','trim|required|min_length[4]');
		$this->form_validation->set_rules('lname','Lname','trim|required|min_length[2]');
		$this->form_validation->set_rules('fname','Fname','trim|required|min_length[2]');

		$data['sections']=$this->Section_model->get_sections();
		
		if($this->form_validation->run()==FALSE){
			$data['main_content']='myadmin/sections/add';
			$this->load->view('myadmin/layouts/main',$data);
		}else{
			$data=array(
					'section_code' =>$this->input->post('code'),
					'section_name' =>$this->input->post('name'),
					'section_adviserlname' =>$this->input->post('lname'),
					'section_adviserfname' =>$this->input->post('fname'),
					'section_advisermname' =>$this->input->post('mname')
				);
			$this->Section_model->insertsection($data);
			$this->session->set_flashdata('section_saved','Your section has been saved.');
			redirect('myadmin/mysections');
		}
	}

public function edit($id){
		$this->form_validation->set_rules('code','Code','trim|required|min_length[1]');
		$this->form_validation->set_rules('name','Name','trim|required|min_length[4]');
		$this->form_validation->set_rules('lname','Lname','trim|required|min_length[2]');
		$this->form_validation->set_rules('fname','Fname','trim|required|min_length[2]');

		$data['section']=$this->Section_model->get_section($id);
		
		if($this->form_validation->run()==FALSE){
			$data['main_content']='myadmin/sections/edit';
			$this->load->view('myadmin/layouts/main',$data,$id);
		}else{
			$data=array(
					'section_code' =>$this->input->post('code'),
					'section_name' =>$this->input->post('name'),
					'section_adviserlname' =>$this->input->post('lname'),
					'section_adviserfname' =>$this->input->post('fname'),
					'section_advisermname' =>$this->input->post('mname')
				);
			$this->Section_model->updatesection($data,$id);
			$this->session->set_flashdata('section_saved','Your section has been updated.');
			redirect('myadmin/mysections');
		}
	}

	public function delete($id){
		$this->Section_model->deletesection($id);
		$this->session->set_flashdata('section_deleted','Your section has been deleted.');
			redirect('myadmin/mysections');
	}
}
?>