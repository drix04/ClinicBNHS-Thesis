
<?php
	class AdminDashboard extends CI_Controller{
	    public function index(){

			$this->session->set_userdata('');
			$session_data = $this->session->userdata('id');
			$this->User_model->get_login($session_data);

			$data['user']=$this->User_model->get_login($session_data);
			// $data['user_name'] =$this->User_model->get_users('5',$page);
			$this->load->view('dashboard/maindashboard',$data);	   										     
	    }
		public function censusform(){

			$this->load->view('forms/census');	   										     

		}
		public function referralform(){

			$this->load->view('forms/referral');	   										     

		}
		public function gatepassslip(){

			$this->load->view('forms/gatepass');	   										     

		}
	}
?>