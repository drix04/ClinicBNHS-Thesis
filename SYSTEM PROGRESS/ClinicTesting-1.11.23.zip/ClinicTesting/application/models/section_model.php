<?php
class Section_model extends CI_Model{
	public function get_sections($order_by = 'section_code', $sort='ASC',$limit=null, $offset=0){
		$this->db->select('*');
		$this->db->from('tbl_section');
						
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}

public function get_filtered_articles($keywords, $order_by = null, $sort='DESC',$limit=null, $offset=0){
		$this->db->select('a.*,b.name as category_name,c.firstname, c.lastname');
		$this->db->from('tblarticles as a');
		$this->db->join('tblcategories as b', 'b.id = a.categoryid','left');
		$this->db->join('tblusers as c', 'c.id = a.userid','left');
		$this->db->like('title',$keywords);
		$this->db->or_like('body',$keywords);
						
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}


public function get_comments($articleid, $order_by = null, $sort='DESC',$limit=null, $offset=0){
		$this->db->select('a.*,b.username,b.avatar,b.avatarname');
		$this->db->from('tblcomments as a');
		$this->db->join('tblusers as b', 'b.id = a.userid','left');
		$this->db->where('articleid',$articleid);
		$this->db->where('approve',1);			
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}

public function get_allcomments($articleid, $order_by = null, $sort='DESC',$limit=null, $offset=0){
		$this->db->select('a.*,b.username');
		$this->db->from('tblcomments as a');
		$this->db->join('tblusers as b', 'b.id = a.userid','left');
		$this->db->where('articleid',$articleid);			
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}

public function countcomment($articleid){
		$this->db->select('count(*) as commentcount');
		$this->db->from('tblcomments as a');
		$this->db->join('tblusers as b', 'b.id = a.userid','left');
		$this->db->where('articleid',$articleid);
		$this->db->where('approve',1);	
		$query =$this->db->get();
		return $query->row();
	}

public function countpcomment($articleid){
		$this->db->select('count(*) as commentcount');
		$this->db->from('tblcomments as a');
		$this->db->join('tblusers as b', 'b.id = a.userid','left');
		$this->db->where('articleid',$articleid);
		$this->db->where('approve',0);	
		$query =$this->db->get();
		return $query->row();
	}

public function countAllcomments($articleid){
		$this->db->select('count(*) as commentcount');
		$this->db->from('tblcomments as a');
		$this->db->join('tblusers as b', 'b.id = a.userid','left');
		$this->db->where('articleid',$articleid);	
		$query =$this->db->get();
		return $query->row();
	}



public function get_menu_items(){
	$this->db->where('inmenu',1);
	$this->db->order_by('order');
	$query=$this->db->get('tblarticles');
	return $query->result();
}
	
public function get_section($id){
	$this->db->where('id',$id);
	$query=$this->db->get('tbl_section');
	return $query->row();
}

public function get_categories($order_by = null, $sort='DESC',$limit=null, $offset=0){
		$this->db->select('*');
		$this->db->from('tblCategories');
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query = $this->db->get();
		return $query->result();
	}

public function get_category($id){
	$this->db->where('id',$id);
	$query=$this->db->get('tblcategories');
	return $query->row();
}

public function insert($data){
	$this->db->insert('tbl_section',$data);
	return true;
}

public function insertcomment($data){
	$this->db->insert('tblcomments',$data);
	return true;
}
public function insertsection($data){
	$this->db->insert('tbl_section',$data);
	return true;
}
public function updatesection($data,$id){
	$this->db->where('id',$id);
	$this->db->update('tbl_section',$data);
	return true;
}

public function publish($id){
	$data = array('ispublished' => 1);
	$this->db->where('articleid',$id);
	$this->db->update('tblarticles',$data);
	return true;
}

public function unpublish($id){
	$data = array('ispublished' => 0);
	$this->db->where('articleid',$id);
	$this->db->update('tblarticles',$data);
	return true;
}


public function unlock($id){
	$data = array('locked' => 0);
	$this->db->where('articleid',$id);
	$this->db->update('tblarticles',$data);
	return true;
}

public function lock($id){
	$data = array('locked' => 1);
	$this->db->where('articleid',$id);
	$this->db->update('tblarticles',$data);
	return true;
}

public function approve($id){
	$data = array('approve' => 1);
	$this->db->where('id',$id);
	$this->db->update('tblcomments',$data);
	return true;
}

public function disapprove($id){
	$data = array('approve' => 0);
	$this->db->where('id',$id);
	$this->db->update('tblcomments',$data);
	return true;
}
public function delcomment($id){
	$this->db->where('id',$id);
	$this->db->delete('tblComments');
	return true;
}

public function delete($id){
	$this->db->where('articleid',$id);
	$this->db->delete('tblarticles');
	return true;
}

public function updatecategory($data,$id){
	$this->db->where('id',$id);
	$this->db->update('tblCategories',$data);
	return true;
}

public function deletesection($id){
	$this->db->where('id',$id);
	$this->db->delete('tbl_section');
	return true;
}


}
?>