<?php
class Groups_model extends CI_Model{
	public function get_usergroups($order_by = null, $sort='ASC',$limit=null, $offset=0){
		$this->db->select('*');
		$this->db->from('tbl_groups');
						
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}

public function get_filtered_articles($keywords, $order_by = null, $sort='DESC',$limit=null, $offset=0){
		$this->db->select('a.*,b.name as category_name,c.firstname, c.lastname');
		$this->db->from('tblarticles as a');
		$this->db->join('tblcategories as b', 'b.id = a.categoryid','left');
		$this->db->join('tblusers as c', 'c.id = a.userid','left');
		$this->db->like('title',$keywords);
		$this->db->or_like('body',$keywords);
						
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}


public function get_usergroup($id){
	$this->db->where('id',$id);
	$query=$this->db->get('tbl_groups');
	return $query->row();
}

public function insertgroup($data){
	$this->db->insert('tbl_groups',$data);
	return true;
}

public function updategroup($data,$id){
	$this->db->where('id',$id);
	$this->db->update('tbl_groups',$data);
	return true;
}


public function deletegroup($id){
	$this->db->where('id',$id);
	$this->db->delete('tbl_groups');
	return true;
}


}
?>