<?php if($this->session->flashdata('section_saved')): ?>
  <?php echo '<p class="alert alert-success">'.$this->session->flashdata('section_saved').'</p>'; ?>
<?php endif; ?>
<?php if($this->session->flashdata('section_deleted')): ?>
  <?php echo '<p class="alert alert-success">'.$this->session->flashdata('section_deleted').'</p>'; ?>
<?php endif; ?>

  <center><h1 class="page-header">Student Sections</h1></center><a href="<?php echo base_url(); ?>myadmin/mysections/add" class="btn btn-success pull-right">Add New Section</a>

    <div class="row">
		<div class ="col-md-10">
		<h2 class="page-subheader">Current Student Sections </h2>
		<div class="table-responsive">
		<table class="table table-striped">
		<thead>
			<tr>
				
				<th width="70">Section Code</th>
				<th>Name</th>
				<th>Adviser</th>
				<th>Created</th>
				<th>Action</th>
              </tr>
		</thead>
		 <tbody>
		   <?php foreach($sections as $section) : ?>
				<tr>
				  <td><?php echo $section->section_code; ?></td>
          <td><?php echo $section->section_name; ?></td>
          <td><?php echo $section->section_adviserlname; ?> ,  <?php echo $section->section_adviserfname; ?> <?php echo $section->section_advisermname; ?> </td>               
          <td><?php echo date("F j, Y, g:i a",strtotime($section->created)); ?></td>
				  <td>
	<a href="<?php echo base_url(); ?>myadmin/mysections/edit/<?php echo $section->id; ?>" class="btn btn-primary">Edit</a>
	<a href="<?php echo base_url(); ?>myadmin/mysections/delete/<?php echo $section->id; ?>" class="btn btn-danger"> Delete</a></td>
				  
                </tr>
				<?php endforeach; ?>
         </tbody>
		</table>
      </div>
	  </div>
	  </div>
