<!--Display Messages-->
<?php if($this->session->flashdata('user_saved')): ?>
  <?php echo '<p class="alert alert-success">'.$this->session->flashdata('user_saved').'</p>'; ?>
<?php endif; ?>
<?php if($this->session->flashdata('user_deleted')): ?>
  <?php echo '<p class="alert alert-success">'.$this->session->flashdata('user_deleted').'</p>'; ?>
<?php endif; ?>

<h1>Users </h1>
<a href="<?php echo base_url(); ?>myadmin/myusers/add" class="btn btn-success pull-right">Add User</a>

<h2 class="page-header">Current Users</h2>
<div class="rtable-responsive">

<table class="table table-stripped">
<thead>
<tr>
<th width="70">#</th>
<th>Name</th>
<th>Username</th>
<th>Email</th>
<th>User group</th>
<th>Status</th>
<th>Action</th>

</tr>
</thead>
<tbody>
<?php foreach($users as $user) : ?>
<tr>
<td><?php echo $user->id; ?></td>
<td><?php echo $user->firstname; ?> <?php echo $user->lastname; ?></td>
<td><?php echo $user->username; ?></td>
<td><?php echo $user->email; ?></td>
<td><?php echo $user->name; ?></td>
<td><?php if ($user->enabled == 1): ?>
		<span class="label label-info">Enabled</span>
	 <?php else: ?>
	 		<span class="label label-success">Disabled</span>
	<?php endif; ?></td>
 <td><a href="<?php echo base_url(); ?>myadmin/myusers/edit/<?php echo $user->id; ?>" class="btn btn-primary">Edit</a>
<a href="<?php echo base_url(); ?>myadmin/myusers/delete/<?php echo $user->id; ?>" class="btn btn-danger">Delete</a>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>