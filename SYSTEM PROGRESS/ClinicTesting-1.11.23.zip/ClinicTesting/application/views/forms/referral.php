<!DOCTYPE html>
<html lang="en">

<head>
  <body>

<link href="./assets/css/bootstrap.min.css" rel="stylesheet" >
<link rel="stylesheet" type="text/css" href="./assets/css/global.css"> 


<!-- <div style="background-color:#490000;padding:80px 10%;font-family:san serif"> -->
    <div class=" backgroundpage">
  <!-- <div class="container col-lg-8 mt-4" style="background-image: linear-gradient(to right,#fff,#800000)"> -->
    
    <section class = "referralform">

          <center><h1 class="referraltitle">REFERRAL FORM</h2></center>
<br>
    <center>
          <div class=" ">
                    <label>Referred to:</label>
                    <input type="text" name="referred to" placeholder=" Enter " class="form control" required>
          </div>
          
          <br>

          <div class="">
                    <label>Date:</label>
                    <input type="text" name="date" placeholder=" Enter Date " class="form control" required>
          </div>
          <br>

          <div class="">
                    <label>Name:</label>
                    <input type="text" name="name" placeholder=" Enter  Name" class="form control" required>
          </div>
          <br>

          <div class="">
            <label>Sex:</label>
            <input type="text" name="sex" placeholder=" Enter sex" class="form control" required>
          </div>
          <br>

          <div class="">
                    <label>Age:</label>
                    <input type="text" name="age" placeholder=" Enter Age" class="form control" required>
          </div>
          <br>

          <div class="">
                    <label>Birthday:</label>
                    <input type="text" name="birthday" placeholder=" Enter Birthday" class="form control" required>
          </div>
          <br>

          <div class="">
                    <label>Grade  & Section:</label>
                    <input type="text" name="gradesection" placeholder="" class="form control" required>
          </div>
          <br>

          <div class="">
                    <label>Name of Adviser:</label>
                    <input type="text" name="nameofadviser" placeholder=" Enter Adviser" class="form control" required>
          </div>
          <br>

          <div class="">
                    <label>Parents/Guardian:</label>
                    <input type="text" name="parentguardian" placeholder="Enter Parent/Guardian" class="form control" required>
          </div>
          <br>

          <div class="">
                    <label>Address:</label>
                    <input type="text" name="address" placeholder="Enter Address " class="form control" required>
          </div>
          <br>

          <div class="">
                    <label>Chief Complains:</label>
                    <input type="text" name="chiefcomplain" placeholder="Enter  Chief Complain" class="form control" required>
          </div>
          <br>

         
        </center>

          <br>
          <br>

      <center><h4 class="vitals">Vital Signs</h4></center>

      <center>
          <div class="col-5 ms-5 mt-3 ps-3">
                  <label>BP:</label>
                  <input type="text" name="bp" class="form control" required>
          </div>
    
          <div class="col-5 ms-5 mt-3 ps-3">
                  <label>RR:</label>
                  <input type="text" name="rr" class="form control"required>
          </div>

          <div class="col-5 ms-5 mt-3 ps-3">
                  <label>PR:</label>
                  <input type="text" name="pr" class="form control" required>
          </div>

          <div class="col-5 ms-5 mt-3 ps-3">
                  <label>02 <br/>Sat:</label>
                  <input type="text" name="sat" class="form control" required>
          </div>
        </center>

          <br>
          <br>

      <div class="mb-2">
                <center><label for="exampleFormControlTextarea1" class="form-label">Working Impressions </label></center> 
                <textarea class="form-control" id="exampleFormControlTextarea1" rows="2"></textarea>
       </div>
            
       <div class="mb-2">
                <center><label for="exampleFormControlTextarea1" class="form-label">Action Taken </label></center>
                <textarea class="form-control" id="exampleFormControlTextarea1" rows="2"></textarea>
       </div>

<br>
       <div class="">
                <label>Reasons for Referral:</label>
                    <form action="/action_page.php">
                                <input type="checkbox" id="FurtherEvaluation" name="FurtherEvaluation" value="FurtherEvaluation">
                                &nbsp;&nbsp;<label for="FurtherEvaluation"> Further Evaluation</label><br>
                                <input type="checkbox" id="Others" name="Others" value="Others">
                                &nbsp;&nbsp; <label for="Others"> Others</label>  <input type="text" name="others" class="form control">
<br>
                              
          </div>

<br><br>
          <div class="referredby">

                    <label>Referred by:</label>
                    <br>
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; GLENDA C. MARTINES, LPT, RN
                       <br>
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Teacher lll/Designated School Nurse (JHS)
                       <br>
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; LIC: #0875702/LIC: #0618073

    </section>    
  
     <section class="referralbuttons">
            <center>
              <!-- <div style= "font-size:20px; font-weight:bold;"> -->
                    <button class="referralbutton " >Save</button> 
                    
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 

                    <button class="referralbutton">Print</button>
                    
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

                    <button class="referralbutton">Cancel</button>

            </center>
        </section>

              </div>      
          </div>
         </div>
    </section>
    </body>
  </head>
</html>