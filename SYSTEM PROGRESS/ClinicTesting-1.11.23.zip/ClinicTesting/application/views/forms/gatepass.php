<!DOCTYPE html>
<html lang="en">

<head>
  <body>

<link href="./assets/css/bootstrap.min.css" rel="stylesheet" >
<link rel="stylesheet" type="text/css" href="./assets/css/global.css"> 


    <div class=" backgroundpage">
    
    <section class = "gatepass">

          <center><h2 class="gatepasstitle">Student Gate Pass</h2></center>

    <center>
<br>
          <div class="gatepassname ">
                    <label>Name:</label>
                    <input type="text" name="name" placeholder=" Enter  Name" class="form control" required>
          </div>

 <br>
          <div class="gatepasssection">
                    <label>Section:</label>
                    <input type="text" name="section" placeholder=" Enter Section " class="form control" required>
          </div>
<br>

          <div class="gatepassdate">
                    <label>Date:</label>
                    <input type="text" name="date" placeholder=" Enter Date " class="form control" required>
          </div>
<br>
          <div class="gatepassreason">
                    <label>Reason:</label>
                    <input type="text" name="reason" placeholder=" Enter Reason" class="form control" required>
          </div>
 <br>

      <div class="gatepassremarks">
                <label for="gatepassRemarks" class="form-label">Remarks: </label>
                <textarea class="form-control" id="gatepassRemarks" ></textarea>
       </div>
            

    </section>    
  
     <section class="gatepassbuttons">
            <center>
         
                    
                    <button class="gatepassbutton">Save</button>
                    
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

                    <button class="gatepassbutton">Print</button>
                    
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

                    <button class="gatepassbutton">Cancel</button>

            </center>
        </section>

              </div>      
          </div>
         </div>
    </section>
    </body>
  </head>
</html>