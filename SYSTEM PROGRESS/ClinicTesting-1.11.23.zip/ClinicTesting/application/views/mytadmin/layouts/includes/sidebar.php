  <!-- Custom styles for this template -->
  <link href="<?php echo base_url();?>myassets/css/dashboard.css" rel="stylesheet">

<div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="<?php if($this->uri->segment(2)=="dashboard"){echo "active";}?>"><a href="<?php echo base_url(); ?>AdminDashboard">Overview</a></li>
            <li class="<?php if($this->uri->segment(2)=="mypatients"){echo "active";}?>"><a href="<?php echo base_url(); ?>myadmin/mydashboard">Patients</a></li>
            <li class="<?php if($this->uri->segment(2)=="mysections"){echo "active";}?>"><a href="<?php echo base_url(); ?>myadmin/mysections">Grade & Section</a></li>
            <!-- <li class="<?php if($this->uri->segment(2)=="myusers"){echo "active";}?>"><a href="<?php echo base_url(); ?>myadmin/myusers">Users</a></li>
            <li class="<?php if($this->uri->segment(2)=="mygroups"){echo "active";}?>"><a href="<?php echo base_url(); ?>myadmin/mygroups">User groups</a></li> -->
            <li class="<?php if($this->uri->segment(2)=="mysettings"){echo "active";}?>"><a href="<?php echo base_url(); ?>myadmin/settings">Settings</a></li>
          </ul>
        </div>