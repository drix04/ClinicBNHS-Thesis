<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>BNHS</title>
    <meta name="description" content="BNHS Clinic System">
    <meta name="author" content="Drix Fabelico">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
	  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js" integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous"></script>
    
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/login.css"> 
    
  </head>
  <body>

    <body>
    <section class="container-fluid"></section>
            <section class="row"></section>
                <section class="col-12 col-sm-6 col-md-3"></section>
       

    <div class="login-box">
        <img src="./assets/images/BNHSlogo.png" class="avatar">

        <!-- action="<?php echo base_url(); ?>auth" -->
        
        <form class="form-signin" method="POST" action="<?php echo site_url('authenticate/login'); ?>" >
             <?php if ($this->session->flashdata('fail_login')) : ?>
                      <?php echo '<p class="alert alert-dismissable alert-danger">' . $this->session->flashdata('fail_login') . '</p>'; ?>
             <?php endif; ?>
                     <div>
                         <h1 class><center>Clinic Login</center></h1>
                    </div>
            <br>
                      <div style="color:black;"><?php echo form_error('username'); ?>
                           <label for="inputEmail" class="sr-only">Username</label>
                              <input type="text" class="form-control" name="username" placeholder=" Enter Username" value="<?php echo set_value('username');?>"  required>
                      </div>

                      <div>
                            <label  for="inputPassword" class="sr-only">Password</label>
                                <input type="password" class="form-control" name="password" placeholder=" Enter Password" value="<?php echo set_value('password');?>" required>
                       </div>

            <br>
            
                       <input type="submit" name="submit" value="Login">
                       <br>
                       <br>
                       <br>
                       
                       <div>
     </div>
     
     <br><br>
     
     
     <div class="footer">
            
            <div class="col-sm-5 col-sm-offset-2 col-md-10 col-md-offset-1 main">
            <center>
              <span class="text"><p>Copyright &copy; <script language="JavaScript" type="text/javascript"> now = new Date
                 theYear=now.getYear()
                 if (theYear < 1900)
                 theYear=theYear+1900
                document.write(theYear)
                </script> | <strong style="color:#800000;">BNHS Clinic System</strong> | All Rights Reserved.
             </center> 
            </div>
          </footer>
                   </div>
  </body>
</html>