<?php
class Nldashboard extends CI_Controller{
	public function __construct(){
		parent:: __construct();
		if(!$this->session->userdata('loggedin')){
			redirect('login');
		}
	}
	
	public function index(){

		if(!empty($this->input->post('keywords'))){
			$data['nutritions']=$this->Patient_model->get_filtered_nutritions($this->input->post('keywords'),'id','DESC',35);
		}else{
			$data['nutritions']=$this->Patient_model->get_allnutritions('id','DESC',NULL);		
		}
		
			
		//view
		
		$data['main_content']= 'nladmin/dashboard/index';
		$this->load->view('nladmin/layouts/main',$data);
	}
	
	public function add(){
		
		$this->form_validation->set_rules('group','Group','required');
		$this->form_validation->set_rules('idnumber','Idnumber','trim|required|min_length[4]');
		$this->form_validation->set_rules('lastname','Lastname','trim|required|min_length[2]');
		$this->form_validation->set_rules('firstname','Firstname','trim|required|min_length[2]');
		$this->form_validation->set_rules('age','Age','trim|required|min_length[1]');
		$this->form_validation->set_rules('grade','Grade','required');
		$this->form_validation->set_rules('section','Section','required');
		$this->form_validation->set_rules('barangay','Barangay','trim|required|min_length[4]');
		$this->form_validation->set_rules('municipality','Municipality','trim|required|min_length[4]');
		$this->form_validation->set_rules('province','Province','trim|required|min_length[4]');
		$data['sections']=$this->User_model->get_sections('id','DESC',NULL);
		$data['usergroups']=$this->Groups_model->get_usergroups('id','ASC',NULL);
		$data['gradelevels']=$this->User_model->get_gradelevels('id','ASC',NULL);
		$data['vaccinations']=$this->User_model->get_vaccinations('id','ASC',NULL);
		 

		if($this->form_validation->run()==FALSE){
				$data['main_content']='nadmin/patients/add';
				$this->load->view('nadmin/layouts/main',$data);
				}else{
				$data=array(
					'patient_groupid' =>$this->input->post('group'),
					'patient_vaccination' =>$this->input->post('vaccination'),
					'patient_id' =>$this->input->post('idnumber'),
					'patient_lastname' =>$this->input->post('lastname'),
					'patient_firstname' =>$this->input->post('firstname'),
					'patient_middlename' =>$this->input->post('middlename'),
					'patient_birthdate' =>$this->input->post('birthday'),
					'patient_age' =>$this->input->post('age'),
					'patient_gender' =>$this->input->post('gender'),
					'patient_gradelevel' =>$this->input->post('grade'),
					'patient_houseno' =>$this->input->post('houseno'),
					'patient_street' =>$this->input->post('street'),
					'patient_brgy' =>$this->input->post('barangay'),
					'patient_municipality' =>$this->input->post('municipality'),
					'patient_province' =>$this->input->post('province'),
					'patient_zipcode' =>$this->input->post('zipcode'),
					'patient_sectionid' =>$this->input->post('section')

				);
			
				$this->Patient_model->insert($data);
				$this->session->set_flashdata('patient_saved','Your Patient Information has been saved.');
				redirect('nadmin/ndashboard');
			}
		}
	


public function edit($id){
		$data['sections']=$this->User_model->get_sections('id','DESC',NULL);
		$data['usergroups']=$this->Groups_model->get_usergroups('id','ASC',NULL);
		$data['gradelevels']=$this->User_model->get_gradelevels('id','ASC',NULL);
		$data['vaccinations']=$this->User_model->get_vaccinations('id','ASC',NULL);
		$this->form_validation->set_rules('group','Group','required');
		$this->form_validation->set_rules('vaccination','Vaccination','required');
		
		$this->form_validation->set_rules('lastname','Lastname','trim|required|min_length[2]');
		$this->form_validation->set_rules('firstname','Firstname','trim|required|min_length[2]');
		$this->form_validation->set_rules('age','Age','trim|required|min_length[1]');
		$this->form_validation->set_rules('grade','Grade','required');
		$this->form_validation->set_rules('section','Section','required');
		$this->form_validation->set_rules('barangay','Barangay','trim|required|min_length[4]');
		$this->form_validation->set_rules('municipality','Municipality','trim|required|min_length[4]');
		$this->form_validation->set_rules('province','Province','trim|required|min_length[4]');
		
		$data['patient']=$this->Patient_model->get_patient($id);
			
		if($this->form_validation->run()==FALSE){
			$data['main_content']='nadmin/patients/edit';
			$this->load->view('nadmin/layouts/main',$data,$id);
		}else{
			$data=array(
					'patient_groupid' =>$this->input->post('group'),
					'patient_vaccination' =>$this->input->post('vaccination'),
					'patient_lastname' =>$this->input->post('lastname'),
					'patient_firstname' =>$this->input->post('firstname'),
					'patient_middlename' =>$this->input->post('middlename'),
					'patient_birthdate' =>$this->input->post('birthday'),
					'patient_age' =>$this->input->post('age'),
					'patient_gender' =>$this->input->post('gender'),
					'patient_gradelevel' =>$this->input->post('grade'),
					'patient_houseno' =>$this->input->post('houseno'),
					'patient_street' =>$this->input->post('street'),
					'patient_brgy' =>$this->input->post('barangay'),
					'patient_municipality' =>$this->input->post('municipality'),
					'patient_province' =>$this->input->post('province'),
					'patient_zipcode' =>$this->input->post('zipcode'),
					'patient_sectionid' =>$this->input->post('section')
				);
			
			$this->Patient_model->updatepatient($data,$id);
			$this->session->set_flashdata('patient_saved','Your Patient information has been updated.');
			redirect('nadmin/ndashboard');
		}
	}

public function checkup($id){
		
		$data['patient']=$this->Patient_model->get_patientinfo($id);
		$data['checkups']=$this->Patient_model->get_nutritions($id);
	
			$data['main_content']='nadmin/patients/preview';
			$this->load->view('nadmin/layouts/main',$data);
		
		}
	

public function delete($id){
			$this->Patient_model->delete($id);
			$this->session->set_flashdata('patient_deleted','Your Patient information has been deleted.');
			redirect('myadmin/mydashboard');
		}

public function deletecheckup($id){
			$this->Patient_model->deletecheckup($id);
			$this->session->set_flashdata('patient_deleted','Your Patient information has been deleted.');
			redirect('myadmin/mydashboard/checkup');
		}

	public function deletenutrition($id){
			$this->Patient_model->deletenutrition($id);
			$this->session->set_flashdata('patient_deleted','Your Nutrition information has been deleted.');
			redirect('nadmin/ndashboard');
		}

public function addcheckup($id){
		
		$this->form_validation->set_rules('weight','Weight','trim|required|min_length[2]');
		$this->form_validation->set_rules('height','Height','trim|required|min_length[1]');
		

		$data['patient']=$this->Patient_model->get_patientinfo($id);

		if($this->form_validation->run()==FALSE){
			$data['main_content']='nadmin/patients/addconsultation';
			$this->load->view('nadmin/layouts/main',$data,$id);
		}else{

			$height2a = $this->input->post('height') * $this->input->post('height');
			$bmi = $this->input->post('weight') / $height2a;
			$taas = $this->input->post('height');
			
			if  ($bmi < 13.4){
					$bmistatus = 'Severly Wasted';
			}elseif ($bmi < 14.6) {
				$bmistatus = 'Wasted';
			}elseif ($bmi < 25.5) {
				$bmistatus = 'Normal';
			}elseif ($bmi < 30) {
				$bmistatus = 'Overweight';
			}elseif ($bmi < 40) {
				$bmistatus = 'Obese';
			}else{
				$bmistatus = 'Extremely Obese';
			}
			
			if ($taas < 1.3){
					$heightforage = 'Severly Stunted';
			}elseif ($bmi < 1.4) {
				$heightforage = 'Stunted';
			}elseif ($bmi < 1.5) {
				$heightforage = 'Normal';
			}else{
				$heightforage = 'Tall';
			}
			
			$data=array(
					'studentid' =>$id,
					'weighingdate' =>$this->input->post('checkupdate'),
					'weight' =>$this->input->post('weight'),
					'height' =>$this->input->post('height'),
					'height2' =>$height2a,
					'bmi' =>$bmi,
					'status' =>$bmistatus,
					'heightage' =>$heightforage
					);
			
			$this->Patient_model->insertnutrition($data);
			$this->session->set_flashdata('patient_saved','New Student Nutritional Information has been saved.');
			redirect('nadmin/ndashboard');
			}
	}


	}

?>