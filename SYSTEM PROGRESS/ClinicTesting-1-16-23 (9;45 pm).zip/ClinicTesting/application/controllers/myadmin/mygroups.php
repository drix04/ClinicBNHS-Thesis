<?php
class Mygroups extends CI_Controller{
	public function __construct(){
	parent:: __construct();
	if (!$this->session->userdata('loggedin')){
			redirect('login');
		}
	}
	public function index(){	
		
		$data['usergroups']=$this->Groups_model->get_usergroups('id','ASC');
		//view
		
		$data['main_content']= 'myadmin/groups/index';
		
		$this->load->view('myadmin/layouts/main',$data);
	}

	public function add(){
		$this->form_validation->set_rules('name','Name','trim|required|min_length[4]');
	
		$data['usergroups']=$this->Groups_model->get_usergroups();
		
		if($this->form_validation->run()==FALSE){
			$data['main_content']='myadmin/groups/add';
			$this->load->view('myadmin/layouts/main',$data);
		}else{
			$data=array(
					
					'name' =>$this->input->post('name')
				);
					
			$this->Groups_model->insertgroup($data);
			$this->session->set_flashdata('group_saved','Your group name has been saved.');
			redirect('myadmin/mygroups');
		}
	}

		public function editgroup($id){
			$this->form_validation->set_rules('name','Name','trim|required|min_length[4]');
		
			$data['usergroup']=$this->Groups_model->get_usergroup($id);
		
		if($this->form_validation->run()==FALSE){
			$data['main_content']='myadmin/groups/edit';
			$this->load->view('myadmin/layouts/main',$data,$id);
		}else{
			$data=array(
					
					'name' =>$this->input->post('name')
									);
			$this->Groups_model->updategroup($data,$id);
			$this->session->set_flashdata('group_saved','Your group name has been updated.');
			redirect('myadmin/mygroups');
		}
	}
	public function delete($id){
		$this->Groups_model->deletegroup($id);
		$this->session->set_flashdata('group_deleted','Your user group has been deleted.');
			redirect('myadmin/mygroups');
	}

}
?>