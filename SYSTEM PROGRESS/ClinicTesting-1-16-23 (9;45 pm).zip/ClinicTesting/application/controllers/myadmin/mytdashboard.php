<?php
class Mytdashboard extends CI_Controller{
	public function __construct(){
		parent:: __construct();
		if(!$this->session->userdata('loggedin')){
			redirect('login');
		}
	}
	
	public function index(){	
		$data['patients']=$this->Patient_model->get_tpatients('patient_id','DESC',NULL);	
			
		//view
		$data['main_content']= 'mytadmin/dashboard/index';
		$this->load->view('mytadmin/layouts/main',$data);
	}
	
	public function add(){
		
		$this->form_validation->set_rules('group','Group','required');
		$this->form_validation->set_rules('idnumber','Idnumber','trim|required|min_length[4]');
		$this->form_validation->set_rules('lastname','Lastname','trim|required|min_length[2]');
		$this->form_validation->set_rules('firstname','Firstname','trim|required|min_length[2]');
		$this->form_validation->set_rules('age','Age','trim|required|min_length[1]');
		$this->form_validation->set_rules('barangay','Barangay','trim|required|min_length[4]');
		$this->form_validation->set_rules('municipality','Municipality','trim|required|min_length[4]');
		$this->form_validation->set_rules('province','Province','trim|required|min_length[4]');
		$data['sections']=$this->User_model->get_sections('id','DESC',NULL);
		$data['usergroups']=$this->User_model->get_usergroups('id','ASC',NULL);
		$data['gradelevels']=$this->User_model->get_gradelevels('id','ASC',NULL);
		$data['vaccinations']=$this->User_model->get_vaccinations('id','ASC',NULL);

		if($this->form_validation->run()==FALSE){
			$data['main_content']='mytadmin/patients/add';
			$this->load->view('mytadmin/layouts/main',$data);
		}else{
			$data=array(
					'patient_groupid' =>$this->input->post('group'),
					'patient_vaccination' =>$this->input->post('vaccination'),
					'patient_comorbidities' =>$this->input->post('comorbidities'),
					'patient_id' =>$this->input->post('idnumber'),
					'patient_lastname' =>$this->input->post('lastname'),
					'patient_firstname' =>$this->input->post('firstname'),
					'patient_middlename' =>$this->input->post('middlename'),
					'patient_birthdate' =>$this->input->post('birthday'),
					'patient_age' =>$this->input->post('age'),
					'patient_gender' =>$this->input->post('gender'),
					'patient_houseno' =>$this->input->post('houseno'),
					'patient_street' =>$this->input->post('street'),
					'patient_brgy' =>$this->input->post('barangay'),
					'patient_municipality' =>$this->input->post('municipality'),
					'patient_province' =>$this->input->post('province'),
					'patient_zipcode' =>$this->input->post('zipcode')
					);
			
			$this->Patient_model->insert($data);
			$this->session->set_flashdata('patient_saved','Your Patient Information has been saved.');
			redirect('mytadmin/mytdashboard');
		}
	}


public function edit($id){
		$data['sections']=$this->User_model->get_sections('id','DESC',NULL);
		$data['usergroups']=$this->User_model->get_usergroups('id','ASC',NULL);
		$data['gradelevels']=$this->User_model->get_gradelevels('id','ASC',NULL);
		$data['vaccinations']=$this->User_model->get_vaccinations('id','ASC',NULL);
		$this->form_validation->set_rules('group','Group','required');
		$this->form_validation->set_rules('vaccination','Vaccination','required');
		$this->form_validation->set_rules('idnumber','Idnumber','trim|required|min_length[4]');
		$this->form_validation->set_rules('lastname','Lastname','trim|required|min_length[2]');
		$this->form_validation->set_rules('firstname','Firstname','trim|required|min_length[2]');
		$this->form_validation->set_rules('age','Age','trim|required|min_length[1]');
		$this->form_validation->set_rules('barangay','Barangay','trim|required|min_length[4]');
		$this->form_validation->set_rules('municipality','Municipality','trim|required|min_length[4]');
		$this->form_validation->set_rules('province','Province','trim|required|min_length[4]');
		
		$data['patient']=$this->Patient_model->get_patient($id);
		
		if($this->form_validation->run()==FALSE){
			$data['main_content']='mytadmin/patients/edit';
			$this->load->view('mytadmin/layouts/main',$data);
		}else{
			$data=array(
					'patient_groupid' =>$this->input->post('group'),
					'patient_vaccination' =>$this->input->post('vaccination'),
					'patient_comorbidities' =>$this->input->post('comorbidities'),
					'patient_lastname' =>$this->input->post('lastname'),
					'patient_firstname' =>$this->input->post('firstname'),
					'patient_middlename' =>$this->input->post('middlename'),
					'patient_birthdate' =>$this->input->post('birthday'),
					'patient_age' =>$this->input->post('age'),
					'patient_gender' =>$this->input->post('gender'),
					'patient_gradelevel' =>$this->input->post('grade'),
					'patient_houseno' =>$this->input->post('houseno'),
					'patient_street' =>$this->input->post('street'),
					'patient_brgy' =>$this->input->post('barangay'),
					'patient_municipality' =>$this->input->post('municipality'),
					'patient_province' =>$this->input->post('province'),
					'patient_zipcode' =>$this->input->post('zipcode'),
					'patient_sectionid' =>$this->input->post('section')
				);
			
			$this->Patient_model->update($data,$id);
			$this->session->set_flashdata('patient_saved','Your Patient information has been updated.');
			redirect('mytadmin/mytdashboard');
		}
	}

public function checkup($id){
		
		$data['patient']=$this->Patient_model->get_patientinfo($id);
		$data['checkups']=$this->Patient_model->get_censuses($id);
	
			$data['main_content']='mytadmin/patients/preview';
			$this->load->view('mytadmin/layouts/main',$data);
		
		}
	

public function delete($id){
			$this->Patient_model->delete($id);
			$this->session->set_flashdata('patient_deleted','Your Patient information has been deleted.');
			redirect('mytadmin/mydashboard');
		}

public function deletecheckup($id){
			$this->Patient_model->deletecheckup($id);
			$this->session->set_flashdata('patient_deleted','Your Patient information has been deleted.');
			redirect('mytadmin/mydashboard/checkup');
		}

public function addcheckup($id){
		$this->form_validation->set_rules('vitalsigns','Vitalsigns','trim|required|min_length[4]');
		$this->form_validation->set_rules('chiefcomplain','Chiefcomplain','trim|required|min_length[4]');
		$this->form_validation->set_rules('treatment','Treatment','trim|required|min_length[4]');

		$data['patient']=$this->Patient_model->get_patientinfo($id);

		if($this->form_validation->run()==FALSE){
			$data['main_content']='mytadmin/patients/addconsultation';
			$this->load->view('mytadmin/layouts/main',$data);
		}else{
			$data=array(
					'patient_id' =>$this->input->post('idnumber'),
					'census_vs' =>$this->input->post('vitalsigns'),
					'census_cc' =>$this->input->post('chiefcomplain'),
					'census_history' =>$this->input->post('history'),
					'census_date' =>$this->input->post('checkupdate'),
					'census_impression' =>$this->input->post('impression'),
					'census_treatment' =>$this->input->post('treatment')
					);
			
			$this->Patient_model->insertcheckup($data);

			$this->session->set_flashdata('patient_saved','New Patient Medical Information has been saved.');
			redirect('mytadmin/mytdashboard/checkup');
			}
	}


	}

?>