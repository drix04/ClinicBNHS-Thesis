
  <center><h1 class="page-header">List of Students</h1><a href="ndashboard/add" class="btn btn-success pull-right">Add Student</a></center>
    <h2 class="page-subheader">List of Students</h2>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Vaccine</th>
              <th>Gender</th>
              <th>Birthdate</th>
              <th>Grade & Section</th>
              <th>Action</th>
            </tr>
          </thead>
        <tbody>
          <?php foreach($students as $student) : ?>
          <tr>
            <td><?php echo $student->patient_id; ?></td>
            <td><?php echo $student->patientname; ?></td>
            <td><?php echo $student->vaccinestatus; ?></td>
             <td><?php if($student->patient_gender == 1) : ?>
                    <?php echo 'Male'; ?>
                  <?php else : ?>
                    <?php echo 'Female';; ?>
                  <?php endif; ?>
                  </td>
            <td><?php echo date("m-d -Y",strtotime($student->patient_birthdate)); ?></td>
            <td><?php echo $student->sectionname; ?></td>
            
            <td>
            <a href="<?php echo base_url(); ?>nadmin/ndashboard/checkup/<?php echo $student->patient_id; ?>" class="btn btn-primary">Add Nutritional Facts</a> 
           <a href="<?php echo base_url(); ?>nadmin/ndashboard/edit/<?php echo $student->patient_id; ?>" class="btn btn-warning">Update Student Info</a>
            </td>
          </tr>
        <?php endforeach; ?>           
    </tbody>
  </table>
</div>

      