  <!-- Custom styles for this template -->
  <link href="<?php echo base_url();?>myassets/css/dashboard.css" rel="stylesheet">

<div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="<?php if($this->uri->segment(2)=="dashboard"){echo "active";}?>"><a href="<?php echo base_url(); ?>AdminDashboard">Overview</a></li>
            <li class="<?php if($this->uri->segment(2)=="mystudents"){echo "active";}?>"><a href="<?php echo base_url(); ?>nadmin/ndashboard">Nutritional Details</a></li>
            <li class="<?php if($this->uri->segment(2)=="myteachers"){echo "active";}?>"><a href="<?php echo base_url(); ?>nladmin/nldashboard">Nutrional List</a></li>
                      
          </ul>  
          </ul>
        </div>