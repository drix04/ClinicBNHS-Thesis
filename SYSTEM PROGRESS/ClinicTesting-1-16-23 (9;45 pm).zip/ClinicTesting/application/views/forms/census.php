<!DOCTYPE html>
<html lang="en">

<head>
  <body>

<link href="./assets/css/bootstrap.min.css" rel="stylesheet" >
<link rel="stylesheet" type="text/css" href="./assets/css/global.css">  

<!-- <div style="background-color:#490000;padding:80px 10%;font-family:san serif"> -->
    <div class=" backgroundpage">
  <!-- <div class="container col-lg-8 mt-4" style="background-image: linear-gradient(to right,#fff,#800000)"> -->
    
    <section class = "cenform">

          <center><h2 class="centitle">Patient Data Sheet</h2></center>

    <center>
          <div class="col-3 ms-5 mt-3 ">
                    <label>Last Name:</label>
                    <input type="text" name="lastname" placeholder=" Enter last name" class="form control" required>
          </div>
          
          <div class="col-3 ms-5 mt-3 ">
                    <label>First Name:</label>
                    <input type="text" name="firstname" placeholder=" Enter first name" class="form control" required>
          </div>

          <div class="col-3 ms-5 mt-3 ">
                    <label>Middle Name:</label>
                    <input type="text" name="middlename" placeholder=" Enter middle name" class="form control" required>
          </div>

          <div class="col-3 ms-5 mt-3 ">
            <label>Street:</label>
            <input type="text" name="street" placeholder=" Enter street" class="form control" required>
          </div>

          <div class="col-3 ms-5 mt-3 ">
                    <label>Barangay:</label>
                    <input type="text" name="barangay" placeholder=" Enter barangay" class="form control" required>
          </div>

          <div class="col-3 ms-5 mt-3 ">
                    <label>Municipality:</label>
                    <input type="text" name="municipality" placeholder=" Enter municipality" class="form control" required>
          </div>

          <div class="col-3 ms-5 mt-3 ">
                    <label>Province:</label>
                    <input type="text" name="province" placeholder=" Enter province" class="form control" required>
          </div>

          <div class="col-3 ms-5 mt-3 ">
                    <label>Age:</label>
                    <input type="text" name="age" placeholder=" Enter Age" class="form control" required>
          </div>

          <div class="col-3 ms-5 mt-3 ">
                    <label>Gender:</label>
                    <input type="text" name="gender" placeholder="Enter Gender" class="form control" required>
          </div>

          <div class="col-3 ms-5 mt-3 ">
                    <label>Year:</label>
                    <input type="text" name="year" placeholder="Enter Year " class="form control" required>
          </div>

          <div class="col-3 ms-5 mt-3 ">
                    <label>Section:</label>
                    <input type="text" name="section" placeholder="Enter  Section" class="form control" required>
          </div>

          <div class="col-3 ms-5 mt-3 ">
                    <label>Date of Visit:</label>
                    <input type="text" name="dateofvisit" placeholder="Enter the date of visit" class="form control" required>
          </div>
        </center>

          <br>
          <br>

      <center><h4 class="vitals">Vital Signs</h4></center>

      <center>
          <div class="col-5 ms-5 mt-3 ps-3">
                  <label>BP:</label>
                  <input type="text" name="bp" class="form control" required>
          </div>
    
          <div class="col-5 ms-5 mt-3 ps-3">
                  <label>RR:</label>
                  <input type="text" name="rr" class="form control"required>
          </div>

          <div class="col-5 ms-5 mt-3 ps-3">
                  <label>PR:</label>
                  <input type="text" name="pr" class="form control" required>
          </div>

          <div class="col-5 ms-5 mt-3 ps-3">
                  <label>02 <br/>Sat:</label>
                  <input type="text" name="sat" class="form control" required>
          </div>
        </center>

          <br>
          <br>

          <div class= "ltextspace">
          <div class="chiefcomplain ">
            <center><label for="chiefcomplain" class="form-label">Chief Complain </label></center> 
            <textarea class="form-control" id="chiefcomplain" rows="2"></textarea>
          </div>
          
          <div class="history">
            <center><label for="history" class="form-label">History </label></center>
            <textarea class="form-control" id="history" rows="2"></textarea>
          </div>
          
          <div class="treatmentgiven">
            <center><label for="treatmentgiven" class="form-label">Treatment Given </label></center>
            <textarea class="form-control" id="treatmentgiven" rows="2"></textarea>
          </div>
          
         </div>
        </section>    
  
     <section class="cenbuttons">
            <center>
                    <button class="cenbutton " >Save</button> 
                    
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                    
                    <a href="admindashboard/referralform/forms/referral"></a>
                    <button class="cenbutton">Referral</button>
                    
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

                    <a href="admindashboard/gatepassslip/forms/gatepass"></a>
                    <button class="cenbutton">Gate pass</button>
                    
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

                    <button class="cenbutton">Cancel</button>

            </center>
        </section>

              </div>      
          </div>
         </div>
    </section>
    </body>
  </head>
</html>