<form method="post" action="<?php echo base_url(); ?>mytadmin/mytdashboard/addcheckup/<?php echo $patient->patient_id; ?>">
			  <div class="row">
			  <div class="col-md-6">
				<h1>Patient Medical Information</h1>
			 
			</div><!-- /.row -->
			<div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
						
				  		<li><a href="<?php echo base_url(); ?>mytadmin/mytdashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				  		<li><a href="<?php echo base_url(); ?>mytadmin/mytdashboard"><i class="fa fa-pencil"></i> Patient</a></li>
				  		<li class="active"><i class="fa fa-plus-square-o"></i> Patient Medical Information</li>
					</ol>

				</div>  
			</div><!-- /.row -->
				<div class="row">
					<h5>
  						<div class="col-sm-2">
    						<label>ID Number : </label>
  						</div>
  						<div class="col-sm-4">
    						<label><?php echo $patient->patient_id; ?> </label>
  						</div> 
  						<div class="col-sm">
							<label>Sex	: <?php if($patient->patient_gender = 1) : ?>
								 		Male
								 	<?php else : ?>
								 		Female
								 	<?php endif; ?></label><br>		
							
						</div>
  						<div class="col-sm-2">
							<label>Patient Name	 :</label>
						</div>
						<div class="col-sm-4">
							<label><?php echo $patient->patientname; ?></label>
						</div>
						<div class="col-sm">
    						<label>Vaccination Status		: <?php echo $patient->vaccinestatus; ?></label>
  						</div>
  						
  						<div class="col-sm-2">
    						<label>Category		:</label>
  						</div>
  						<div class="col-sm-4">
    						<label><?php echo $patient->name; ?> </label>
  						</div>	
						 <div class="col-sm">
							<label for="start">Birthdate	:</label>
							<input type="date" id="start" name="birthday" value="<?php echo date("Y-m-d",strtotime($patient->patient_birthdate)); ?>" disable>
						</div>
						
						<div class="col-sm-2">
							<label>Age		: </label>
						</div>
						<div class="col-sm-4">
							<label><?php echo $patient->patient_age;  ?></label>
						</div>
							<div class="col-sm">
							<label>Address  	: </label>
							<label><?php echo $patient->address; ?></label>
						</div>
						</h5>
				
					<hr style="width:100%;height:4px;border-width:0;color:gray;background-color:gray;text-align:center;margin-left:0">	
				<div class="col-sm-12">
					
					<a href="<?php echo base_url(); ?>mytadmin/mytdashboard/addcheckup/<?php echo $patient->patient_id; ?>" class="btn btn-success pull-right">Add Checkup Details</a></center>
					
					<a href="<?php echo base_url(); ?>mytadmin/mytdashboard" class="btn btn-warning pull-right"> Close </a>
				
	
    			<h4 class="page-subheader"><strong> Medical History</strong></h4> 
				
      			<div class="table-responsive">
        		<table class="table table-primary">
          		<thead>
            	<tr>
              		<th>ID</th>
              		<th>Date</th>
              		<th>Vital Signs</th>
              		<th>Chief Complain</th>
              		<th>Impression</th>
              		<th>History</th>
              		<th>Treatment</th>
              		<th>Action Taken</th>
              		<th>Description </th>
              		
            	</tr>
          		</thead>
        	<tbody>
          
          	<?php foreach($checkups as $checkup) : ?>
          	<tr>
            <td><?php echo $checkup->census_id; ?></td>
            <td><?php echo date("F j, Y, g:i a",strtotime($checkup->census_date)); ?></td>
           	<td><?php echo $checkup->census_vs; ?></td>
           	<td><?php echo $checkup->census_cc; ?></td>
           	<td><?php echo $checkup->census_history; ?></td>
           	<td><?php echo $checkup->census_impression; ?></td>
           	<td><?php echo $checkup->census_treatment; ?></td>
           	<td><?php if ($checkup->prescription == 1): ?>
				<span class="label label-info">For Referral</span>
	 			<?php elseif ($checkup->prescription == 2): ?>
	 			<span class="label label-warning">For Gatepass</span>
				<?php else: ?>
	 			<span class="label label-success">Others</span>
				<?php endif; ?></td>
           	<td><?php echo $checkup->reason; ?></td>

            
          </tr>
        <?php endforeach; ?>               
    </tbody>
  </table>
</div>

						
</div><!-- /.row -->
</form>
