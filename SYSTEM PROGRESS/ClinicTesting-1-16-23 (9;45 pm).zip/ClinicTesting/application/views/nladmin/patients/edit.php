 <?php echo validation_errors('<p class="alert alert-dismissable alert-danger">'); ?>
<form method="post" action="<?php echo base_url(); ?>nadmin/ndashboard/edit/<?php echo $patient->patient_id; ?>">
			  <div class="row">
			  <div class="col-md-6">
				<h2>Update Student Information</h2>
			  </div>
				<div class="col-md-6">
					<div class="btn-group pull-right">
						<input type="submit" name="submit" class="btn btn-info" value="Save" />
						<a href="<?php echo base_url(); ?>nadmin/ndashboard" class="btn btn-warning">Close</a>
				</div>
			  </div>
			</div><!-- /.row -->
			<div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
				  		<li><a href="<?php echo base_url(); ?>nadmin/ndashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				  		<li><a href="<?php echo base_url(); ?>nadmin/ndashboard"><i class="fa fa-pencil"></i> Student</a></li>
				  		<li class="active"><i class="fa fa-plus-square-o"></i> Update Student Information</li>
					</ol>
				</div>  
			</div><!-- /.row -->
				<div class="row">
					<div class="col-lg-12">
						<div class="form-group">
							<label>Category</label>
							<select name="group" class="form-control">
								 <option value="0">Select Category</option>
								 <?php foreach($usergroups as $usergroup) : ?>
								 	<?php if($usergroup->id == $patient->patient_groupid) : ?>
								 		<?php $selected = 'selected'; ?>
								 	<?php else : ?>
								 		<?php $selected = ''; ?>
								 	<?php endif; ?>
								 	<option value="<?php echo $usergroup->id; ?>" <?php echo $selected; ?>><?php echo $usergroup->name; ?></option>
								 <?php endforeach; ?>       
							</select>
						</div>
						<div class="form-group">
							<label>Category</label>
							<select name="vaccination" class="form-control">
								 <option value="0">Select Vaccination Status</option>
								  	<?php foreach($vaccinations as $vaccination) : ?>
								 	<?php if($vaccination->id == $patient->patient_vaccination) : ?>
								 		<?php $selected = 'selected'; ?>
								 	<?php else : ?>
								 		<?php $selected = ''; ?>
								 	<?php endif; ?>
								 	<option value="<?php echo $vaccination->id; ?>" <?php echo $selected; ?>><?php echo $vaccination->vaccinestatus; ?></option>
								 <?php endforeach; ?>        
							</select>
						</div>
						<div class="form-group">
								<label>ID Number</label>
								<input class="form-control" type="text" maxlength="11" name="idnumber" value="<?php echo $patient->patient_id; ?>" disabled />
						</div>

						<div class="form-group">
							<label>Lastname</label>
							<input class="form-control" type="text" maxlength="75" name="lastname" value="<?php echo $patient->patient_lastname; ?>"  />
						</div>
						<div class="form-group">
							<label>Firstname</label>
							<input class="form-control" type="text" maxlength="75" name="firstname" value="<?php echo $patient->patient_firstname; ?>" />
						</div>
						<div class="form-group">
							<label>Middlename</label>
							<input class="form-control" type="text" maxlength="75" name="middlename" value="<?php echo $patient->patient_middlename; ?>"  />
						</div>
						<div class="form-group">
							<label>Sex</label><br>		
							<label for="gender" class="radio-inline">
        					<input type="radio" name="gender" id="gender" value="1" <?php echo ($patient->patient_gender== 1) ? 'checked' : ''; ?>> Male
       						 </label>
        					<label class="radio-inline">
           					 <input type="radio" name="gender" id="gender" value="0" <?php echo ($patient->patient_gender == 0) ? 'checked' : ''; ?>> Female
        					</label>
						</div>
								
						 <div class="form-group">
							<label for="start">Birthdate:</label>
							<input type="date" id="start" name="birthday" value="<?php echo date("Y-m-d",strtotime($patient->patient_birthdate)); ?>">
						</div>
						<div class="form-group">
							<label>Age</label>
							<input class="form-control" type="number" maxlength="2" name="age" value="<?php echo $patient->patient_age;  ?>"  />
						</div>
						<div class="form-group">
							<label>Grade Level</label>
							<select name="grade" class="form-control">
								 <option value="0">Select Grade Level</option>
								 <?php foreach($gradelevels as $gradelevel) : ?>
								 	<?php if($gradelevel->id == $patient->patient_gradelevel) : ?>
								 		<?php $selected = 'selected'; ?>
								 	<?php else : ?>
								 		<?php $selected = '7'; ?>
								 	<?php endif; ?>
								 	<option value="<?php echo $gradelevel->id; ?>" <?php echo $selected; ?>><?php echo $gradelevel->description; ?></option>
								 <?php endforeach; ?>       
							</select>
						</div>
						<div class="form-group">
							<label>Section</label>
							<select name="section" class="form-control">
								 <option value="0">Select Student Section</option>
								 <?php foreach($sections as $section) : ?>
								 	<?php if($section->id == $patient->patient_sectionid) : ?>
								 		<?php $selected = 'selected'; ?>
								 	<?php else : ?>
								 		<?php $selected = ''; ?>
								 	<?php endif; ?>
								 	<option value="<?php echo $section->id; ?>" <?php echo $selected; ?>><?php echo $section->section_code; ?> <?php echo $section->section_name; ?></option>
								 <?php endforeach; ?>       
							</select>
						</div>
						<div class="form-group">
							<label>House No/Purok</label>
							<input class="form-control" type="text" maxlength="5" name="houseno" value="<?php echo $patient->patient_houseno;  ?>"  />
						</div>
						<div class="form-group">
							<label>Street Address</label>
							<input class="form-control" type="text" maxlength="75" name="street" value="<?php echo $patient->patient_street;  ?>"  />
						</div>
						<div class="form-group">
							<label>Barangay</label>
							<input class="form-control" type="text" maxlength="75" name="barangay" value="<?php echo $patient->patient_brgy;  ?>"  />
						</div>
						<div class="form-group">
							<label>Municipality</label>
							<input class="form-control" type="text" maxlength="75" name="municipality" value="<?php echo $patient->patient_municipality;  ?>"  />
						</div>
						<div class="form-group">
							<label>Province</label>
							<input class="form-control" type="text" maxlength="75" name="province" value="<?php echo $patient->patient_province;  ?>"  />
						</div>
						<div class="form-group">
							<label>Zipcode</label>
							<input class="form-control" type="number" maxlength="4" name="zipcode" value="<?php echo $patient->patient_zipcode;  ?>"  />


	
</div>
</div><!-- /.row -->
</form>
