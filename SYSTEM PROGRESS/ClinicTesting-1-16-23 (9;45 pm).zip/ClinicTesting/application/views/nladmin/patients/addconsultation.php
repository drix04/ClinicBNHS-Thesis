<!--Display form validation errors-->
<?php echo validation_errors('<p class="alert alert-dismissable alert-danger">'); ?>
<form method="post" action="<?php echo base_url(); ?>nadmin/ndashboard/addcheckup/<?php echo $patient->patient_id; ?>">
			  <div class="row">
			  <div class="col-md-10">
				<h2>Student New Nutritional Details</h2>
			 
			</div><!-- /.row -->
			<div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
						
				  		<li><a href="<?php echo base_url(); ?>nadmin/ndashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				  		<li><a href="<?php echo base_url(); ?>nadmin/ndashboard"><i class="fa fa-pencil"></i> Student</a></li>
				  		<li class="active"><i class="fa fa-plus-square-o"></i> Student Nutritional Details</li>
					</ol>
				<hr style="width:100%;height:4px;border-width:0;color:gray;background-color:gray;text-align:center;margin-left:0">
				</div>  
			</div><!-- /.row -->
				<div class="row">
										
				<div class="col-sm-12">
					
									
    			<strong></strong> <h3 class="page-subheader">Student Nutritional Detail</h3></strong>
					
					  	<h4>	
						
						<div class="col-sm-8">
							<label>Student Name	 :</label>
							<label><?php echo $patient->patientname; ?></label>
						</div>
						<div class="col-sm-4">
							<label>Age		: <?php echo $patient->patient_age;  ?></label>
						</div>
  						<div class="col-sm-4">
							<label>Sex	: <?php if($patient->patient_gender = 1) : ?>
								 		Male
								 	<?php else : ?>
								 		Female
								 	<?php endif; ?></label><br>		
							
						</div>
						
  													
						 
						<div class="col-sm-4">
							<label>Grade Level	: <?php echo $patient->description; ?></label>
						</div>
						
							<div class="col-sm-4">
							<label>Section 		:  <?php echo $patient->sectionname; ?></label>
						</div>
						<div class="col-sm-4">
							<label>Adviser		: <?php echo $patient->adviser; ?></label>
						</div>

						<div class="col-sm-8">
							<label>Address  	: <?php echo $patient->address; ?></label>
						</div>
						
						</h4>
						
						<hr style="width:100%;height:4px;border-width:0;color:gray;background-color:gray;text-align:center;margin-left:0">

						<div class="form-group">
						<div class="col-sm-2">
							<label>ID Number : </label>
						</div>
						
						<div class="col-sm-2">
								<input type="text" size="10"  name="idnumber" value="<?php echo $patient->patient_id; ?>" disabled/>
						</div>
					</div>


						<div class="form-group">
							<label for="start">Select Date of Weighing:</label>
							<input type="date" id="start" name="checkupdate" value="2000-01-01">
						</div>


						<div class="form-group">
							<label>Weight in Kilograms *</label>
							<input class="form-control" type="number" name="weight" min="15" max="150" step ="0.1" value="<?php echo set_value('weight'); ?>" placeholder="Enter Student Weight in Kilograms" />
						</div>
						<div class="form-group">
							<label>Height in Meters (Example: 1.3)*</label>
							<input class="form-control" type="number" name="height"  min="0.5" max = "2.5" step="0.1" value="<?php echo set_value('height'); ?>" placeholder="Enter Student Height in Meters" />
						</div>

						

					<center> 
						
						<input type="submit" name="submit" class="btn btn-info" value="Save" />
						<a href="<?php echo base_url(); ?>nadmin/ndashboard/checkup/<?php echo $patient->patient_id; ?>" class="btn btn-warning"> Close</a>
				</center> 
					
						
</div><!-- /.row -->
</form>