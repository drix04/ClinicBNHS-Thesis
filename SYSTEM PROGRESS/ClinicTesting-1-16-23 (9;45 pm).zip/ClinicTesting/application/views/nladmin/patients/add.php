<!--Display form validation errors-->
<?php echo validation_errors('<p class="alert alert-dismissable alert-danger">'); ?>
<form method="post" action="<?php echo base_url(); ?>nadmin/ndashboard/add">
			  <div class="row">
			  <div class="col-lg-6">
				<h2>Add Student Information</h2>
			  </div>
				<div class="col-lg-6">
					<div class="btn-group pull-right">
						<input type="submit" name="submit" class="btn btn-info" value="Save" />
						<a href="<?php echo base_url(); ?>nadmin/ndashboard" class="btn btn-warning">Close</a>
				</div>
			  </div>
			</div><!-- /.row -->
			<div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
				  		<li><a href="<?php echo base_url(); ?>nadmin/ndashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				  		<li><a href="<?php echo base_url(); ?>nadmin/ndashboard"><i class="fa fa-pencil"></i> Student</a></li>
				  		<li class="active"><i class="fa fa-plus-square-o"></i> Add Student</li>
					</ol>
				</div>  
			</div><!-- /.row -->
				<div class="row">
					<div class="col-lg-12">
						<div class="form-group">
							<label>Student Category *</label>
							<select name="group" class="form-control">
								 <option value="0">Select Category</option>
								 <?php foreach($usergroups as $group) : ?>
								 	<option value="<?php echo $group->id; ?>"><?php echo $group->name; ?></option>
								 <?php endforeach; ?>       
							</select>
						</div>
						<div class="form-group">
							<label>Student Vaccination Status *</label>
							<select name="vaccination" class="form-control">
								 <option value="0">Select Vaccination Status</option>
								 <?php foreach($vaccinations as $vaccine) : ?>
								 	<option value="<?php echo $vaccine->id; ?>"><?php echo $vaccine->vaccinestatus; ?></option>
								 <?php endforeach; ?>       
							</select>
						</div>	
						<div class="form-group">
							<label>ID Number *</label>
							<input class="form-control" type="number" name="idnumber"  maxlength="11" value="<?php echo set_value('idnumber'); ?>" placeholder="Enter Student ID Number" />
						</div>
						<div class="form-group">
							<label>Lastname *</label>
							<input class="form-control" type="text" name="lastname" maxlength="75" value="<?php echo set_value('lastname'); ?>" placeholder="Enter Student Lastname" />
						</div>
						<div class="form-group">
							<label>Firstname *</label>
							<input class="form-control" type="text" name="firstname" maxlength="75" value="<?php echo set_value('firstname'); ?>" placeholder="Enter Student Firstname" />
						</div>
						<div class="form-group">
							<label>Middlename</label>
							<input class="form-control" type="text" name="middlename" maxlength="75" value="<?php echo set_value('middlename'); ?>" placeholder="Enter Student Middlename" />
						</div>
						

						<div class="form-group">
							<label>Gender *</label><br>		
							<label for="gender" class="radio-inline">
							<input type="radio" name="gender" value="1" checked> Male
							</label>
							<label class="radio-inline">
							<input type="radio" name="gender" value="0"> Female
							</label>
						</div>

						<div class="form-group">
							<label for="start">Birthdate: *</label>
							<input type="date" id="start" name="birthday"	value="2000-01-01">
						</div>
						<div class="form-group">
							<label>Age</label>
							<input class="form-control" type="number" maxlength="2" name="age" value="<?php echo set_value('age'); ?>" placeholder="Enter Student Age" />
						</div>
						<div class="form-group">
							<label>Student Grade Level *</label>
							<select name="grade" class="form-control">
								 <option value="0">Select Grade Level</option>
								 <?php foreach($gradelevels as $gradelevel) : ?>
								 	<option value="<?php echo $gradelevel->id; ?>"><?php echo $gradelevel->description; ?></option>
								 <?php endforeach; ?>       
							</select>
						</div>	
						<div class="form-group">
							<label>Section *</label>
							<select name="section" class="form-control">
								 <option value="0">Select Section</option>
								 <?php foreach($sections as $section) : ?>
								 	<option value="<?php echo $section->id; ?>"><?php echo $section->section_code; ?> - <?php echo $section->section_name; ?></option>
								 <?php endforeach; ?>       
							</select>
						</div>

						<div class="form-group">
							<label>House No/Purok </label>
							<input class="form-control" type="text" maxlength="5" name="houseno" value="<?php echo set_value('houseno'); ?>" placeholder="Enter Student House Number or Purok" />
						</div>
						<div class="form-group">
							<label>Street Address</label>
							<input class="form-control" type="text" maxlength="75" name="street" value="<?php echo set_value('street'); ?>" placeholder="Enter Student Street Address" />
						</div>
						<div class="form-group">
							<label>Barangay *</label>
							<input class="form-control" type="text" maxlength="75" name="barangay" value="<?php echo set_value('barangay'); ?>" placeholder="Enter Student Barangay Address" />
						</div>
						<div class="form-group">
							<label>Municipality *</label>
							<input class="form-control" type="text" maxlength="75" name="municipality" value="<?php echo set_value('municipality'); ?>" placeholder="Enter Student Municipality Address" />
						</div>
						<div class="form-group">
							<label>Province *</label>
							<input class="form-control" type="text" maxlength="75" name="province" value="<?php echo set_value('province'); ?>" placeholder="Enter Student Province Address" />
						</div>
						<div class="form-group">
							<label>Zipcode</label>
							<input class="form-control" type="number" maxlength="4" name="zipcode" value="<?php echo set_value('zipcode'); ?>" placeholder="Enter Student Zipcode" />
						</div>


						
					</div>
				</div><!-- /.row -->
			</form>
