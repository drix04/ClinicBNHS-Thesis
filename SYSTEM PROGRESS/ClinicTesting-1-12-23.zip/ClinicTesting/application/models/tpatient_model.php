<?php
class TPatient_model extends CI_Model{
	public function get_patients($order_by = null, $sort='DESC',$limit=null, $offset=0){
		$this->db->select('*');
		$this->db->from('qryteachers');
		
						
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}

	public function get_patientinfo($id){
		$this->db->where('patient_id',$id);
		$query=$this->db->get('qryteachers');
		return $query->row();
	}	

	public function get_patient($id){
		$this->db->where('patient_id',$id);
		$query=$this->db->get('tbl_patient');
		return $query->row();
	}

	public function get_censuses($patientid,$order_by = 'census_id', $sort='DESC'){
		$this->db->select('*');
		$this->db->from('tbl_census');
		$this->db->where('patient_id',$patientid);
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}

public function get_filtered_patients($keywords, $order_by = null, $sort='DESC',$limit=null, $offset=0){
		$this->db->select('*');
		$this->db->from('qryteachers');
		$this->db->like('patientname',$keywords);
		$this->db->or_like('patient_id',$keywords);
						
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}
	
	
	public function insert($data){
	$this->db->insert('tbl_patient',$data);
	return true;
	}

	public function insertcheckup($data){	
	$this->db->insert('tbl_census',$data);
	return true;
	}

	public function delete($id){
		$this->db->where('patient_id',$id);
		$this->db->delete('tbl_patient');
		return true;
	}
public function deletecheckup($id){
		$this->db->where('census_id',$id);
		$this->db->delete('tbl_census');
		return true;
	}

	public function update($data,$id){
		$this->db->where('patient_id',$id);
		$this->db->update('tbl_patient',$data);
		return true;
	}

	

}
	
?>