
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <title>Clinic Dashboard </title>
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/global.css"> 

    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

     <meta name="viewport" content="width=device-width, initial-scale=1.0">
   </head>
<body>
    <!-- SIDEBAR -->
  <div class="sidebar">
    <div class="logo-details">
      <i class='bx bxl-windows icon'></i>
        <div class="logo_name">BNHS CLINIC</div>
        <i class='bx bx-menu' id="btn" ></i>
      </div>

    <ul class="nav-list">
      <!-- <li>
          <i class='bx bx-search' ></i>
         <input type="text" placeholder="Search...">
         <span class="tooltip">Search</span>
      </li> -->
      <li>
        <a href="">
          <i class='bx bx-grid-alt'></i>
          <span class="links_name">Dashboard</span>
        </a>
         <span class="tooltip">Dashboard</span>
      </li>
      <!-- <li>
       <a href="#">
         <i class='bx bx-user' ></i>
         <span class="links_name">User</span>
       </a>
       <span class="tooltip">User</span>
     </li> -->
     
     <li>
       <a href="printcensus">
         <i class='bx bx-folder' ></i>
         <span class="links_name">Reports</span>
       </a>
       <span class="tooltip">Reports</span>
     </li>
    
     <li>
       <a href="#">
         <i class='bx bx-cog' ></i>
         <span class="links_name">Setting</span>
       </a>
       <span class="tooltip">Setting</span>
     </li>

     <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
    

     <li>
     <a href="<?php echo site_url('authenticate/logout'); ?>">
         <i class='bx bx-log-out' ></i>
         <span class="links_name">Logout</span>
       </a> 
        <span class="tooltip">Logout</span> 
      </li>

     <li class="profile">
         <div class="profile-details">
           <img src="<?php echo base_url(); ?>./assets/images/BNHSlogo.png" alt="profileImg">
           <div class="name_job">
             <!-- <div class="name" >Juan Dela Cruz</div>
             <div class="job" >Admin</div> -->
             <!-- <div class="name"; ><?php echo $user->user_name;?></div>
             <div class="job"; ><?php echo $user->user_type;?></div> -->

           </div>
<!--          
         <div>
             <a href="<?php echo site_url('authenticate/logout'); ?>">
                <i class='bx bx-log-out' id="log_out"></i>
                  <center> <span class="links_name">Logout</span></center>
           </a>
                    <span class="tooltip">Logout</span>
        </div> -->
     </li>
    </ul>
  </div>

  <!-- <div><img src="./assets/images/loginbg.jpg" class="bg"></div> -->
  <!-- DASHBOARD PAGE -->
  <section class="home-section">
      <div class="title">Clinic Dashboard</div>
      <br><br>
      <br><br>
      <br><br>
      <center><div class="choices">Choose A Patient Below</div></center>
      

  <!-- BUTTONS     -->
  <section class="buttons">
      <center>
        <div>
        <a href="myadmin/mydashboard">
               <button class="button">Student</button> 
        </a>
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        
        <a href="mytadmin/mytdashboard">
             <button class="button">Teacher</button>

        </a>

      </center>
  </section>
  <script src="./assets/js/dashboardopen.js"></script>
</body>
</html>
