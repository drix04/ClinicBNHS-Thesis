 <!--Display Messages-->
    <?php if($this->session->flashdata('group_saved')): ?>
  <?php echo '<p class="alert alert-success">'.$this->session->flashdata('group_saved').'</p>'; ?>
<?php endif; ?>
<?php if($this->session->flashdata('group_deleted')): ?>
  <?php echo '<p class="alert alert-success">'.$this->session->flashdata('group_deleted').'</p>'; ?>
<?php endif; ?>
  <h1 class="page-header">User Groups</h1><a href="<?php echo base_url(); ?>myadmin/mygroups/add" class="btn btn-success pull-right">Add Group</a>
    <div class="row">
    <div class ="col-md-10">
    <h2>Latest Groups </h2>
    <div class="table-responsive">
    <table class="table table-striped">
    <thead>
              <thead>
                <tr>
                  <th width="70">#</th>
                  <th>Name</th>               
				  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
              	<?php foreach($usergroups as $group) : ?>
	                <tr>
	                  <td><?php echo $group->id; ?></td>              
	                  <td><?php echo $group->name; ?></td>
					  <td><a href="<?php echo base_url(); ?>myadmin/mygroups/editgroup/<?php echo $group->id; ?>" class="btn btn-primary">Edit</a> 
					  <a href="<?php echo base_url(); ?>myadmin/mygroups/delete/<?php echo $group->id; ?>" class="btn btn-danger">Delete</a></td>
	                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>