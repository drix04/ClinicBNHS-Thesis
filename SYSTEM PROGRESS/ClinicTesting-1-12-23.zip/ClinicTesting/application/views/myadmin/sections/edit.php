<!--Display form validation errors-->
    <?php echo validation_errors('<p class="alert alert-dismissable alert-danger">'); ?>
<form method="post" action="<?php echo base_url(); ?>myadmin/mysections/edit/<?php echo $section->id; ?>">
				  <div class="row">
				  <div class="col-md-6">
					<h1>Edit Section</h1>
				  </div>
					<div class="col-md-6">
						<div class="btn-group pull-right">
							<input type="submit" name="submit" class="btn btn-primary" value="Save" />
							<a href="<?php echo base_url(); ?>myadmin/mysections" class="btn btn-danger">Close</a>
					</div>
				  </div>
				</div><!-- /.row -->
				<div class="row">
					<div class="col-lg-12">
						<ol class="breadcrumb">
					  <li><a href="<?php echo base_url(); ?>myadmin/mydashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
					  <li><a href="<?php echo base_url(); ?>myadmin/mysections"><i class="fa fa-pencil"></i> Sections</a></li>
					  <li class="active"><i class="fa fa-plus-square-o"></i> Edit Section</li>
					</ol>
					</div>  
				</div><!-- /.row -->
					<div class="row">
						<div class="col-lg-12">
							<div class="form-group">
								<label>Section Code</label>
								<input class="form-control" type="text" name="code" value="<?php echo $section->section_code; ?>" />
							</div>
							<div class="form-group">
								<label>Section Name</label>
								<input class="form-control" type="text" name="name" value="<?php echo $section->section_name; ?>" />
							</div>
							<div class="form-group">
								<label>Section Adviser Lastname</label>
								<input class="form-control" type="text" name="lname" value="<?php echo $section->section_adviserlname; ?>" />
							</div>
							<div class="form-group">
								<label>Section Adviser Firstname</label>
								<input class="form-control" type="text" name="fname" value="<?php echo $section->section_adviserfname; ?>" />
							</div>
							<div class="form-group">
								<label>Section Adviser Middlename</label>
								<input class="form-control" type="text" name="mname" value="<?php echo $section->section_advisermname; ?>" />
							</div>				
						</div>
					</div><!-- /.row -->
</form>