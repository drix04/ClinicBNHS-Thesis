<?php
class Myusers extends CI_Controller{
	public function __construct(){
		parent:: __construct();
		if(!$this->session->userdata('loggedin')){
			redirect('login');
		}
	}
	
	public function index(){		
		
		$data['users']=$this->User_model->get_users('id','DESC',20);
		
		$data['usergroups']=$this->User_model->get_usergroups('id','ASC',5);
		//view
		
		$data['main_content']= 'myadmin/users/index';
		
		$this->load->view('myadmin/layouts/main',$data);
	}

	public function add(){
		$this->form_validation->set_rules('firstname','Firstname','trim|required|min_length[4]');
		$this->form_validation->set_rules('lastname','Lastname','trim|required|min_length[4]');
		$this->form_validation->set_rules('emailadd','emailadd','trim|required|min_length[4]');
		$this->form_validation->set_rules('username','Username','trim|required|min_length[4]');
		$this->form_validation->set_rules('password','Password','trim|required|min_length[4]');
		
		
		$data['users']=$this->User_model->get_users();
		$data['groups']=$this->User_model->get_groups();

		if($this->form_validation->run()==FALSE){
			$data['main_content']='myadmin/users/add';
			$this->load->view('myadmin/layouts/main',$data);
		}else{
			$data = array(
					'firstname' =>$this->input->post('firstname'),
					'lastname' =>$this->input->post('lastname'),
					'email' =>$this->input->post('emailadd'),
					'username' =>$this->input->post('username'),
					'password' => md5($this->input->post('password')),
					'groupid' =>$this->input->post('usergroup'),
					'enabled' =>$this->input->post('enabled'),
					
				);
			$this->User_model->insert($data);
			$this->session->set_flashdata('user_saved','The user information has been saved.');
			redirect('myadmin/myusers');
		}
	}

public function edit($id){
		$this->form_validation->set_rules('firstname','Firstname','trim|required|min_length[2]');
		$this->form_validation->set_rules('lastname','Lastname','trim|required|min_length[2]');
		$this->form_validation->set_rules('emailadd','emailadd','trim|required|min_length[4]');
		$this->form_validation->set_rules('username','Username','trim|required|min_length[4]');
		$this->form_validation->set_rules('password','Password','trim|required|min_length[4]');
		
		$data['users']=$this->User_model->get_users();
		$data['groups']=$this->User_model->get_groups();
		$data['user']=$this->User_model->get_user($id);

		if($this->form_validation->run()==FALSE){
			$data['main_content']='myadmin/users/edit';
			$this->load->view('myadmin/layouts/main',$data);
		}else{
			$data = array(
					'firstname' =>$this->input->post('firstname'),
					'lastname' =>$this->input->post('lastname'),
					'email' =>$this->input->post('emailadd'),
					'username' =>$this->input->post('username'),
					'password' =>md5($this->input->post('password')),
					'groupid' =>$this->input->post('usergroup'),
					'enabled' =>$this->input->post('enabled'),
									
				);
			$this->User_model->update($data,$id);
			$this->session->set_flashdata('user_saved','The user information has been saved.');
			redirect('myadmin/myusers');
		}
	}
	public function delete($id){
		$this->db->where('id',$id);
		$this->db->delete('tbl_users');
		redirect('myadmin/myusers');
		return true;

	}

}
?>