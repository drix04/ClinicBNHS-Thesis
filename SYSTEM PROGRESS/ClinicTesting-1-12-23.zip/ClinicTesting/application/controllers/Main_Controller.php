<?php
	class Main_Controller extends CI_Controller{			
		public function index(){				
			$this->load->view('login');			
		}				
	}
?>