<?php
class Authenticate extends CI_Controller{
	public function login(){	
		$this->form_validation->set_rules('username','Username','trim|required|min_length[4]');
		$this->form_validation->set_rules('password','Password','trim|required|min_length[4]');
		if($this->form_validation->run() == FALSE){
			$this->load->view('login');
		}else{
				$username = $this->input->post('username');
				$password = $this->input->post('password');	

		$data['userlevel'] = $this->Authenticate_model->checkuser($username,$password);

		if(($data['userlevel']->groupid == 1) && ($data['userlevel']->enabled == 1)){

		$user_id = $this->Authenticate_model->login_user($username,$password);
			if($user_id){
					$session_data = array(
						'id' => $id,
						'username' => $username,
						'userid' => $userid,
						'last_login' => date('Y-m-d H:i:s'),
						'loggedin' => true
					);
					$this->session->set_userdata($session_data);
				    $session_data = $this->session->userdata('id');
				   	$this->User_model->get_login($session_data);
					$users = $this->User_model->get_login($session_data);
					
					
				   	$this->load->library('session');
				$this->session->set_userdata($userdata);
				$this->session->set_flashdata('pass_login','Your are now logged in.');
				redirect('AdminDashboard'); 
			}
		}else{
			$this->session->session_destroy;
			$this->session->set_flashdata('access_denied','Your are not allowed to access this feature. Contact your administrator.');
			redirect('login'); 
		}
	}
	}
	
	public function logout(){
		//unset the user data
		$this->session->unset_userdata('loggedin');
		$this->session->unset_userdata('userid');
		$this->session->unset_userdata('username');
		$this->session->session_destroy;
		$this->session->set_flashdata('pass_logout','Your have been logged out.');
		redirect('login');
	}
}
?>