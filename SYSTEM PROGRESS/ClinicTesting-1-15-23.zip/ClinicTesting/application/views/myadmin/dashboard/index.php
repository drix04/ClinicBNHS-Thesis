
  <center><h1 class="page-header">Patients</h1><a href="mydashboard/add" class="btn btn-success pull-right">Add Patient</a></center>
    <h2 class="page-subheader">List of patients</h2>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Address</th>
              <th>Vaccine</th>
              <th>Gender</th>
              <th>Age</th>
              <th>Birthdate</th>
              <th>Grade & Section</th>
              <th>Adviser</th>
              <th>Action</th>
            </tr>
          </thead>
        <tbody>
          <?php foreach($patients as $patient) : ?>
          <tr>
            <td><?php echo $patient->patient_id; ?></td>
            <td><?php echo $patient->patientname; ?></td>
            <td><?php echo $patient->address; ?></td>
            <td><?php echo $patient->vaccinestatus; ?></td>
             <td><?php if($patient->patient_gender == 1) : ?>
                    <?php echo 'Male'; ?>
                  <?php else : ?>
                    <?php echo 'Female';; ?>
                  <?php endif; ?>
                  </td>
            <td><?php echo $patient->patient_age; ?></td>
            <td><?php echo date("m-d -Y",strtotime($patient->patient_birthdate)); ?></td>
            <td><?php echo $patient->sectionname; ?></td>
            <td><?php echo $patient->adviser; ?></td>
            <td>
            <a href="<?php echo base_url(); ?>myadmin/mydashboard/checkup/<?php echo $patient->patient_id; ?>" class="btn btn-primary">Checkup</a> 
            <a href="<?php echo base_url(); ?>myadmin/mydashboard/edit/<?php echo $patient->patient_id; ?>" class="btn btn-warning">Update</a>
            <a href="<?php echo base_url(); ?>myadmin/mydashboard/delete/<?php echo $patient->patient_id; ?>" class="btn btn-danger">Delete</a>
            </td>
          </tr>
        <?php endforeach; ?>           
    </tbody>
  </table>
</div>

      