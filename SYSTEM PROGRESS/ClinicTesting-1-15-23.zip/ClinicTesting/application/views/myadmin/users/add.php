<?php echo validation_errors('<div class="alert alert-danger">','</div>'); ?>
<form method="post" action="<?php echo base_url(); ?>myadmin/myusers/add" enctype="multipart/form-data">
			  <div class="row">
			  <div class="col-lg-6">
				<h1>Add User</h1>
			  </div>
			</div><!-- /.row -->
			  				
			  				<div class="form-group">
								<label>First Name*</label>
								<input type="text" class="form-control" name ="firstname" placeholder="Enter your first name" />
							</div>
							<div class="form-group">
								<label>Last Name*</label>
								<input type="text" class="form-control" name ="lastname" placeholder="Enter your last name"/ >
							</div>
							<div class="form-group">
								<label>Email Address*</label>
								<input type="email" class="form-control" name ="emailadd" placeholder="Enter Your Email Address"/ >
							</div>
							<div class="form-group">
								<label>Choose Username*</label>
								<input type="text" class="form-control" name ="username" placeholder="Enter Your Username"/ >
							</div>
							<div class="form-group">
								<label>Choose Password*</label>
								<input type="password" class="form-control" name ="password" placeholder="Enter Your Password"/ >
							</div>

							 <div class="form-group">
							<label>Group</label>
							<select name="usergroup" class="form-control">
								 <option value="0">Everyone</option>
								 <?php foreach($groups as $group) : ?>
								 	<option value="<?php echo $group->id; ?>"><?php echo $group->name; ?></option>
								 <?php endforeach; ?>            
							</select>
							</br>
							<div class="form-group">
							<label>Enabled</label><br>		
							<label for="enabled" class="radio-inline">
							<input type="radio" name="enabled" value="1" checked> yes
							</label>
							<label class="radio-inline">
							<input type="radio" name="enabled" value="0"> No
							</label>
						</div>
							<input name="submit" type="submit" class="btn btn-primary" value="Register" />
      						<a href="<?php echo base_url(); ?>myadmin/myusers" class="btn btn-default"> Cancel </a>
</form>