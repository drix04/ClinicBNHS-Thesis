  <!-- Custom styles for this template -->
  <link href="<?php echo base_url();?>myassets/css/dashboard.css" rel="stylesheet">

<div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
            <li class="<?php if($this->uri->segment(2)=="dashboard"){echo "active";}?>"><a href="<?php echo base_url(); ?>AdminDashboard">Overview</a></li>
            <li class="<?php if($this->uri->segment(2)=="mystudents"){echo "active";}?>"><a href="<?php echo base_url(); ?>myadmin/mydashboard">Students</a></li>
            <li class="<?php if($this->uri->segment(2)=="myteachers"){echo "active";}?>"><a href="<?php echo base_url(); ?>mytadmin/mytdashboard">Teachers</a></li>
            <li class="<?php if($this->uri->segment(3)=="mysections"){echo "active";}?>"><a href="<?php echo base_url(); ?>myadmin/mysections">Grade & Section</a></li>
            <li class="<?php if($this->uri->segment(3)=="myusers"){echo "active";}?>"><a href="<?php echo base_url(); ?>myadmin/myusers">Users</a></li>
            
          </ul>  
          </ul>
        </div>