<form method="post" action="<?php echo base_url(); ?>nadmin/ndashboard/addcheckup/<?php echo $patient->patient_id; ?>">
			  <div class="row">
			  <div class="col-md-6">
				<h1>Student Nutritional Information</h1>
			 
			</div><!-- /.row -->
			<div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
						
				  		<li><a href="<?php echo base_url(); ?>nadmin/ndashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				  		<li><a href="<?php echo base_url(); ?>nadmin/ndashboard"><i class="fa fa-pencil"></i> Student</a></li>
				  		<li class="active"><i class="fa fa-plus-square-o"></i> Student Nutritional Information</li>
					</ol>

				</div>  
			</div><!-- /.row -->
				<div class="row">
					<h5>
  						<div class="col-sm-2">
    						<label>ID Number : </label>
  						</div>
  						<div class="col-sm-4">
    						<label><?php echo $patient->patient_id; ?> </label>
  						</div> 
  						<div class="col-sm">
							<label>Sex	: <?php if($patient->patient_gender = 1) : ?>
								 		Male
								 	<?php else : ?>
								 		Female
								 	<?php endif; ?></label><br>		
							
						</div>
  						<div class="col-sm-2">
							<label>Student Name	 :</label>
						</div>
						<div class="col-sm-4">
							<label><?php echo $patient->patientname; ?></label>
						</div>
						<div class="col-sm">
    						<label>Vaccination Status		: <?php echo $patient->vaccinestatus; ?></label>
  						</div>
  						
  						<div class="col-sm-2">
    						<label>Category		:</label>
  						</div>
  						<div class="col-sm-4">
    						<label><?php echo $patient->name; ?> </label>
  						</div>	
						 <div class="col-sm">
							<label for="start">Birthdate	:</label>
							<input type="date" id="start" name="birthday" value="<?php echo date("Y-m-d",strtotime($patient->patient_birthdate)); ?>" disable>
						</div>
						<div class="col-sm-2">
							<label>Grade Level	: </label>
						</div>
						<div class="col-sm-4">
							<label><?php echo $patient->description; ?></label>
						</div>
						<div class="col-sm">
							<label>Age		: <?php echo $patient->patient_age;  ?></label>
						</div>

						<div class="col-sm-2">
							<label>Section 		: </label>
						</div>
						<div class="col-sm-4">
							<label><?php echo $patient->sectionname; ?></label>
						</div>
						<div class="col-sm">
							<label>Adviser		: <?php echo $patient->adviser; ?></label>
						</div>

						<div class="col-sm-2">
							<label>Address  	: </label>
						</div>
						<div class="col-sm-10">
							<label><?php echo $patient->address; ?></label>
						</div>
						</h5>
				
					<hr style="width:100%;height:4px;border-width:0;color:gray;background-color:gray;text-align:center;margin-left:0">	
				<div class="col-sm-12">
					
					<a href="<?php echo base_url(); ?>nadmin/ndashboard/addcheckup/<?php echo $patient->patient_id; ?>" class="btn btn-success pull-right">Add New Nutritional Details</a></center>
					
					<a href="<?php echo base_url(); ?>nadmin/ndashboard" class="btn btn-warning pull-right"> Close </a>
				
	
    			<h4 class="page-subheader"><strong> Student Nutritional History</strong></h4> 
				
      			<div class="table-responsive">
        		<table class="table table-primary">
          		<thead>
            	<tr>
              		<th>ID</th>
              		<th>Weighing Date</th>
              		<th>Weight</th>
              		<th>Height</th>
              		<th>Height2</th>
              		<th>BMI</th>
              		<th>Nutritional Status</th>
              		<th>Height-For-Age</th>
              		<th>Action</th>
              	             		
            	</tr>
          		</thead>
        	<tbody>
          
          	<?php foreach($checkups as $checkup) : ?>
          	<tr>
            	<td><?php echo $checkup->id; ?></td>
            	<td><?php echo date("F j, Y",strtotime($checkup->weighingdate)); ?></td>
           		<td><?php echo $checkup->weight; ?></td>
           		<td><?php echo $checkup->height; ?></td>
           		<td><?php echo $checkup->height2; ?></td>
           		<td><?php echo $checkup->bmi; ?></td>
           		<td><?php echo $checkup->status; ?></td>
           		<td><?php echo $checkup->heightage; ?></td>
           		<td>
          
            <a href="<?php echo base_url(); ?>nadmin/ndashboard/deletenutrition/<?php echo $checkup->id; ?>" class="btn btn-danger">Delete</a>
            </td>
           	</tr>
        <?php endforeach; ?>           
    </tbody>
  </table>
</div>

						
</div><!-- /.row -->
</form>
