
  <center><h1 class="page-header">Nutritional Status Report</h1><a href="ndashboard/add" class="btn btn-success pull-right">Filter List</a></center>
    <h2 class="page-subheader">List of Nutritional Details</h2>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Student ID</th>
              <th>Name</th>
              <th>Vaccine</th>
              <th>Gender</th>
              <th>Grade & Section</th>
              <th>Birthdate</th>
              <th>Weighing Date</th>
              <th>Weight</th>
              <th>Height</th>
              <th>Height2</th>
              <th>BMI</th>
              <th>Nutrional Status</th>
              <th>Heigh-For-Age</th>
              
            </tr>
          </thead>
        <tbody>
          <?php foreach($nutritions as $nutrition) : ?>
          <tr>
            <td><?php echo $nutrition->id; ?></td>
            <td><?php echo $nutrition->studentid; ?></td>
            <td><?php echo $nutrition->patientname; ?></td>
            <td><?php echo $nutrition->vaccinestatus; ?></td>
             <td><?php if($nutrition->patient_gender == 1) : ?>
                    <?php echo 'Male'; ?>
                  <?php else : ?>
                    <?php echo 'Female';; ?>
                  <?php endif; ?>
                  </td>
             <td><?php echo $nutrition->sectionname; ?></td>
            <td><?php echo date("m-d -Y",strtotime($nutrition->patient_birthdate)); ?></td>
             <td><?php echo date("m-d -Y",strtotime($nutrition->weighingdate)); ?></td>
            <td><?php echo $nutrition->weight; ?></td>
            <td><?php echo $nutrition->height; ?></td>
            <td><?php echo $nutrition->height2; ?></td>
            <td><?php echo $nutrition->bmi; ?></td>
            <td><?php echo $nutrition->status; ?></td>
            <td><?php echo $nutrition->heightage; ?></td>
                      
          </tr>
        <?php endforeach; ?>           
    </tbody>
  </table>
</div>

      