
  <div style="padding-top: 0px;" class="custom">
    <div style="padding-top: 0px;">
 	    <center><img src="<?php echo base_url();?>assets/images/edu.png"   width="70px" height="70px"></center>				
    </div>
	    <table width="100%"> 



			<tr>	
				<td style="font-size:14px;" align="center" width="100%">Republic of the Philippines</td>			
							
			</tr>	
		
			
			<tr>	
				<td style="font-size:20px;" align="center" width="100%">Department of Education</td>			
							
			</tr>	

			<tr>	
				<td style="font-size:14px;" align="center" width="100%">Region II - CAGAYAN VALLEY</td>			
							
			</tr>	

			<tr>	
				<td style="font-size:14px;" align="center" width="100%">SCHOOLS DIVISION OF NUEVA VIZCAYA</td>			
							
			</tr>	

		<table width="100%">	
		

			
<figure class="text-center">

	<tr>	
				<td style="font-size:25px;" align="center" width="100%">PATIENT DATA SHEET</td>			
							
			</tr>	

</figure>

<br></br>



<table width="100%">
<center>	
<div class="mb-3">
  <label for="formGroupExampleInput" class="form-label">Name :</label>
  <input type="text" class="form-control" id="formGroupExampleInput" >
</div>
<div class="mb-3">
  <label for="formGroupExampleInput2" class="form-label">Address :</label>
  <input type="text" class="form-control" id="formGroupExampleInput2" >
</div>

<div class="mb-3">
  <label for="formGroupExampleInput" class="form-label">Age and Gender :</label>
  <input type="text" class="form-control" id="formGroupExampleInput" >
</div>
<div class="mb-3">
  <label for="formGroupExampleInput2" class="form-label">Year and Section :</label>
  <input type="text" class="form-control" id="formGroupExampleInput2" >
</div>

	
<div class="mb-3">
  <label for="formGroupExampleInput" class="form-label">Date of Visit :</label>
  <input type="text" class="form-control" id="formGroupExampleInput" >
</div>
<table width="100%">
</center>
</div>
<br></br>


<table>
	<tbody>
		<tr>
	<center>	
<h5><th>Vital Signs:</th></h5>
</tr>
<tr>
<td></td>
<td>BP</td>
<td>-</td>
</tr>

</tr>
<tr>
<td></td>
<td>RR</td>
<td>-</td>
</tr>

</tr>
<tr>
<td></td>
<td>PR</td>
<td>-</td>
</tr>

<tr>
<td></td>
<td>02 Sat</td>
<td>-</td>
</tr>
</tbody>
</table>
</div>
</center>	

<center>	

<table width="100%">
	<div class="mb-3">
  			<label for="formGroupExampleInput" class="form-label">Chief Complain :</label>
  			<input type="text" class="form-control" id="formGroupExampleInput" >
	</div>
	
	<div class="mb-3">
 			 <label for="formGroupExampleInput2" class="form-label">History :</label>
 			 <input type="text" class="form-control" id="formGroupExampleInput2" >
	</div>


	<div class="mb-3">
 			 <label for="formGroupExampleInput" class="form-label">Treatment give :</label>
  			<input type="text" class="form-control" id="formGroupExampleInput" >
	</div>

</div>
</center>	


<table width="100%">


	
	<br><br>
	<br><br>
	<center>
		<p>Copyright @2022 | BNHS Clinic System | All Rights Reserved.</p>
	</center>
	

<style type="text/css">
.custom {
	font-family: ArialNarrow;
	font-size:12px;
}
</style>

<script type="text/javascript">
    $(document).ready(function(){
        window.print();
    })
    window.onafterprint = function() {
        history.go(-1);
    };
</script>