<!DOCTYPE html>
<html lang="en">
<link rel="stylesheet" type="text/css" href="./assets/css/global.css">  

<head>
  <body>
  <section class="studentlist">
    <h1 class="studenth1">Student List<h1>



    <section class="studentbuttons">
            <center>
                    <button class="studentbutton " >Save</button> 
                    
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; 
                    
                    <a href="admindashboard/referralform/forms/referral"></a>
                    <button class="studentbutton">Referral</button>
                    
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

                    <a href="admindashboard/gatepassslip/forms/gatepass"></a>
                    <button class="studentbutton">Gate pass</button>
                    
                    &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;

                    <button class="studentbutton">Cancel</button>

            </center>
        </section>
        </section>
    </body>
</head>


</html>
