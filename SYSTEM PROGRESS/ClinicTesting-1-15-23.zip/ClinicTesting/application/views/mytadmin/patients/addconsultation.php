<!--Display form validation errors-->
<?php echo validation_errors('<p class="alert alert-dismissable alert-danger">'); ?>
<form method="post" action="<?php echo base_url(); ?>mytadmin/mytdashboard/addcheckup/<?php echo $patient->patient_id; ?>">
			  <div class="row">
			  <div class="col-md-10">
				<h2>Patient New Medical Checkup Information</h2>
			 
			</div><!-- /.row -->
			<div class="row">
				<div class="col-lg-12">
					<ol class="breadcrumb">
						
				  		<li><a href="<?php echo base_url(); ?>mytadmin/mytdashboard"><i class="fa fa-dashboard"></i> Dashboard</a></li>
				  		<li><a href="<?php echo base_url(); ?>mytadmin/mytdashboard"><i class="fa fa-pencil"></i> Patient</a></li>
				  		<li class="active"><i class="fa fa-plus-square-o"></i> Patient Medical Information</li>
					</ol>
				<hr style="width:100%;height:4px;border-width:0;color:gray;background-color:gray;text-align:center;margin-left:0">
				</div>  
			</div><!-- /.row -->
				<div class="row">
										
				<div class="col-sm-12">
					
									
    			<strong></strong> <h3 class="page-subheader">Medical History</h3></strong>
					
					  	<h4>	
						
						<div class="col-sm-8">
							<label>Patient Name	 :</label>
							<label><?php echo $patient->patientname; ?></label>
						</div>
						<div class="col-sm-4">
							<label>Age		: <?php echo $patient->patient_age;  ?></label>
						</div>
  						<div class="col-sm-4">
							<label>Sex	: <?php if($patient->patient_gender = 1) : ?>
								 		Male
								 	<?php else : ?>
								 		Female
								 	<?php endif; ?></label><br>		
							
						</div>
						
  										
						 
						

						<div class="col-sm-8">
							<label>Address  	: <?php echo $patient->address; ?></label>
						</div>
						
						</h4>
						
						<hr style="width:100%;height:4px;border-width:0;color:gray;background-color:gray;text-align:center;margin-left:0">

						<div class="form-group">
						<div class="col-sm-2">
							<label>ID Number : </label>
						</div>
						
						<div class="col-sm-2">
								<input type="text" size="10"  name="idnumber" value="<?php echo $patient->patient_id; ?>" disabled/>
						</div>
					</div>


						<div class="form-group">
							<label for="start">Select Date of Checkup/Visit:</label>
							<input type="date" id="start" name="checkupdate" value="2000-01-01">
						</div>
						<div class="form-group">
							<label>Vital Signs</label>
							<textarea class="form-control" name="vitalsigns" rows="3"><?php echo set_value('vitalsigns'); ?></textarea>
						</div>	

							
						<div class="form-group">
							<label>Chief Complain</label>
							<textarea class="form-control" name="chiefcomplain" rows="3"><?php echo set_value('chiefcomplain'); ?> </textarea>
						</div>
						<div class="form-group">
							<label>Medical History</label>
							<textarea class="form-control" name="history" rows="3"><?php echo set_value('history'); ?></textarea>
						</div>
						
						<div class="form-group">
							<label>Medical Treatment</label>
							<textarea class="form-control" name="treatment" rows="3"><?php echo set_value('treatment'); ?></textarea>
						</div>		
						<div class="form-group">
							<label>Medical Impression</label>
							<textarea class="form-control" name="impression" rows="3"><?php echo set_value('impression'); ?></textarea>
						</div>		

						<div class="form-group">
							<label>Action Taken</label>
							<select name="prescription" class="form-control">
								 <option value="0">Select Action Taken</option>
								 <option value="1">For Refferal</option>
								 <option value="2">For Gatepass</option>
								 <option value="3">Others</option>
								 
							</select>
						</div>	
						<div class="form-group">
							<label>Action Description</label>
							<textarea class="form-control" name="reason" rows="3"><?php echo set_value('reason'); ?></textarea>
						</div>
					</div>

					<center> 
						
						<input type="submit" name="submit" class="btn btn-info" value="Save" />
						<a href="<?php echo base_url(); ?>mytadmin/mytdashboard/checkup/<?php echo $patient->patient_id; ?>" class="btn btn-warning"> Close</a>
				</center> 
					
						
</div><!-- /.row -->
</form>