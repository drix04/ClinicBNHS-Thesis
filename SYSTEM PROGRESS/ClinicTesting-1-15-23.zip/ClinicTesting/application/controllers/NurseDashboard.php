
<?php
	class NurseDashboard extends CI_Controller{
	    public function index(){	      						
			$this->session->set_userdata('');
			$session_data = $this->session->userdata('id');
			$this->User_model->get_login($session_data);
			$users = $this->User_model->get_login($session_data);
						
			$data['users']=$this->User_model->get_login($session_data);												
			$data['main_content'] = 'dashboard/maindashboard';
			$this->load->view('dashboard/maindashboard',$data);	   										     
	    }
	}
?>