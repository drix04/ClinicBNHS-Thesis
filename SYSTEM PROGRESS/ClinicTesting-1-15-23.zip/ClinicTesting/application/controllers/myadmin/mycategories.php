<?php
class Mycategories extends MY_Controller{
	public function __construct(){
	parent:: __construct();
	if (!$this->session->userdata('loggedin')){
			redirect('admin/login');
		}
	}
	public function index(){	
		$data['categories']=$this->Article_model->get_categories('id','DESC',5);	
		//view
		
		$data['main_content']= 'admin/categories/index';
		
		$this->load->view('admin/layouts/main',$data);
	}

public function add(){
		$this->form_validation->set_rules('name','Name','trim|required|min_length[4]');
		
		$data['categories']=$this->Article_model->get_categories();
		
		if($this->form_validation->run()==FALSE){
			$data['main_content']='admin/categories/add';
			$this->load->view('admin/layouts/main',$data);
		}else{
			$data=array(
					'name' =>$this->input->post('name')
				);
			$this->Article_model->insertcategory($data);
			$this->session->set_flashdata('category_saved','Your category has been saved.');
			redirect('admin/mycategories');
		}
	}

public function edit($id){
		$this->form_validation->set_rules('name','Name','trim|required|min_length[4]');
		
		$data['category']=$this->Article_model->get_category($id);
		
		if($this->form_validation->run()==FALSE){
			$data['main_content']='admin/categories/edit';
			$this->load->view('admin/layouts/main',$id,$data);
		}else{
			$data=array(
					'name' =>$this->input->post('name')
				);
			$this->Article_model->updatecategory($data,$id);
			$this->session->set_flashdata('category_saved','Your category has been updated.');
			redirect('admin/mycategories');
		}
	}

	public function delete($id){
		$this->Article_model->deletecategory($id);
		$this->session->set_flashdata('category_deleted','Your category has been deleted.');
			redirect('admin/mycategories');
	}
}
?>