<?php
class Authenticate extends MY_Controller{
	public function login(){	
		$this->form_validation->set_rules('username','Username','trim|required|min_length[4]');
		$this->form_validation->set_rules('password','Password','trim|required|min_length[4]');
		if($this->form_validation->run() == FALSE){
			$this->load->view('admin/layouts/login');
		}else{
				$username = $this->input->post('username');
				$password = $this->input->post('password');	

		$data['userlevel'] = $this->Authenticate_model->checkuser($username,$password);

		if(($data['userlevel']->groupid == 2) && ($data['userlevel']->enabled == 1)){

		$user_id = $this->Authenticate_model->login_user($username,$password);
			if($user_id){
				$userdata = array(
					'userid'=> $user_id,
					'username'=> $username,
					'loggedin'=> TRUE
				);
				$this->session->set_userdata($userdata);
				$this->session->set_flashdata('pass_login','Your are now logged in.');
				redirect('admin/dashboard'); 
			}
		}else{
			$this->session->session_destroy;
			$this->session->set_flashdata('access_denied','Your are not allowed to access this feature. Contact your administrator.');
			redirect('admin/login'); 
		}
	}
	}
	
	public function logout(){
		//unset the user data
		$this->session->unset_userdata('loggedin');
		$this->session->unset_userdata('userid');
		$this->session->unset_userdata('username');
		$this->session->session_destroy;
		$this->session->set_flashdata('pass_logout','Your have been logged out.');
		redirect('admin/login');
	}
}
?>