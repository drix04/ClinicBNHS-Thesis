<?php
	class User_model extends CI_model{
		private $user_id;	
		private $user_name;
		private $user_type;
		private $user_password;
		private $enabled;
				
		public function setUserID($Userid) { $this->user_id=$Userid;}
		public function getUserID (){ return $this->user_id;}
			
		public function setUserName($Username) { $this->user_name=$Username;}
		public function getUserName(){ return $this->user_name;}
		
		public function setUserPassword($Userpassword) { $this->user_password=$Userpassword;}
		public function getUserPassword(){ return $this->user_password;}
				
		public function setUserType($Usertype) { $this->user_type=$Usertype;}
		public function getUserType(){ return $this->user_type;}
		
		public function setUserIsActive($Userisactive) { $this->enabled=$Userisactive;}
		public function getUserIsActive(){ return $this->enabled;}
	
		public function get_user_details(){
			$this->db->select('*');
			$this->db->from('tbl_users');
			$this->db->where('user_name',trim($this->getUsername()));					
			$query=$this->db->get();				
			return $query->row();	
		}
		public function get_login($session_data){
			$this->db->select('*');
			$this->db->from('tbl_users');
			$this->db->where('id', $session_data);
			$this->db->where('enabled = 1');					
			$result=$this->db->get();			
			if($result->num_rows() == 1){
				return $result->row();
			}else{
				return false;
			}
		}

		public function get_users($order_by = null, $sort='DESC',$limit=null, $offset=0){
		$this->db->select('a.*,b.name');
		$this->db->from('tbl_users as a');
		$this->db->join('tbl_groups as b', 'b.id = a.groupid','left');
						
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}

		public function login_user($username,$password){						
			$enc_password = md5($password);	
			$this->db->select('*'); 
			$this->db->from('tbl_users');
			$this->db->where('user_name',$username);
			$this->db->where('user_password',$enc_password);
			$this->db->where('enabled = 1');						
			$result=$this->db->get();			
			if($result->num_rows() == 1){
				return $result->row();
			}else{
				return false;
			}			
		}
	
	public function get_usergroups($order_by = null, $sort='DESC',$limit=null, $offset=0){
		$this->db->select('*');
		$this->db->from('tbl_groups');
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}

	public function get_groups($order_by = null, $sort='DESC',$limit=null, $offset=0){
		$this->db->select('*');
		$this->db->from('tbl_groups');
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}

public function get_vaccinations($order_by = null, $sort='DESC',$limit=null, $offset=0){
		$this->db->select('*');
		$this->db->from('tbl_vaccination');
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}
	public function get_gradelevels($order_by = null, $sort='DESC',$limit=null, $offset=0){
		$this->db->select('*');
		$this->db->from('tbl_gradelevel');
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}

	public function get_sections($order_by = 'section_code', $sort='ASC',$limit=null, $offset=0){
		$this->db->select('*');
		$this->db->from('tbl_section');
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}

	public function get_user($userid){
		$this->db->where('id',$userid);
		$query=$this->db->get('tbl_users');
		return $query->row();
	}

	public function check_patientid($id){
		$this->db->where('patient_id',$id);
		$query=$this->db->get('tbl_patient');
		return $query->row();
	}


	public function delete($id){
		$this->db->where('id',$id);
		$this->db->delete('tb_lusers');
		return true;
	}
	public function update($data,$id){
	$this->db->where('id',$id);
	$this->db->update('tbl_users',$data);
	return true;
	}

	public function insert($data){
	$this->db->insert('tbl_users',$data);
	return true;
	}
	}	
?>