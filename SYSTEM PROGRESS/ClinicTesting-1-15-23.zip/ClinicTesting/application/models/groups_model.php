<?php
class Groups_model extends CI_Model{
	public function get_usergroups($order_by = null, $sort='ASC',$limit=null, $offset=0){
		$this->db->select('*');
		$this->db->from('qrystudentgrp');
						
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}

public function get_usertgroups($order_by = null, $sort='ASC',$limit=null, $offset=0){
		$this->db->select('*');
		$this->db->from('qryteachersgrp');
						
		if($limit != null){
			$this->db->limit($limit,$offset);
		}
		if ($order_by != null){
			$this->db->order_by($order_by,$sort);
		}
		$query =$this->db->get();
		return $query->result();
	}

public function get_usergroup($id){
	$this->db->where('id',$id);
	$query=$this->db->get('tbl_groups');
	return $query->row();
}

public function insertgroup($data){
	$this->db->insert('tbl_groups',$data);
	return true;
}

public function updategroup($data,$id){
	$this->db->where('id',$id);
	$this->db->update('tbl_groups',$data);
	return true;
}


public function deletegroup($id){
	$this->db->where('id',$id);
	$this->db->delete('tbl_groups');
	return true;
}


}
?>